function [niggli_criteria_fullfilled,type] = function_NIGGLI_ADD_CRYSTAL(a,b,c,alpha,beta,gamma)

abc=a^2 <= b^2 && b^2 <= c^2;

if abc==false
    niggli_criteria_fullfilled=false;
    type=0;
else 
    sep_angle = alpha < 90 && beta < 90 && gamma < 90;
    
    if sep_angle==true
        type=1;
        test1=c*cosd(alpha)<=b/2;
        if test1==false
            niggli_criteria_fullfilled=false;
        else
            test2=c*cosd(beta)<=a/2;
            if test2==false
                niggli_criteria_fullfilled=false;
            else
                test3=b*cosd(gamma)<=a/2;
                if test3==false
                    niggli_criteria_fullfilled=false;
                else
                    niggli_criteria_fullfilled=true;
                end
            end 
        end
    else
        sep_angle2 = alpha >= 90 && beta >= 90 && gamma >= 90;
        
        if sep_angle2==false
            niggli_criteria_fullfilled=false;
            type=0;
        else
            test4=c*abs(cosd(alpha))<=b/2;
            type=2;
            if test4==false
                niggli_criteria_fullfilled=false;
            else
                test5=c*abs(cosd(beta))<=a/2;
                if test5==false
                    niggli_criteria_fullfilled=false;
                else
                    test6=b*abs(cosd(gamma))<=a/2;
                    if test6==false
                        niggli_criteria_fullfilled=false;
                    else
                        lasttest=b*c*abs(cosd(alpha))+a*c*abs(cosd(beta))+...
                            a*b*abs(cosd(gamma))<=((a^2+b^2)/2);
                        if lasttest==false
                            niggli_criteria_fullfilled=false;
                        else
                            niggli_criteria_fullfilled=true;
                        end 
                    end 
                end 
            end 
    
        end 
            
    end 
end

end

