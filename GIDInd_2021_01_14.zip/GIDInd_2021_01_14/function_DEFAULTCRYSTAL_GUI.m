function [qxyz,gspec] = ...
    function_DEFAULTCRYSTAL_GUI(a,b,c,alpha,beta,gamma,hkmax,lmax,u,v,w)

hk=(-hkmax:hkmax)'; 
lvec=(-lmax:lmax)';

M=zeros(length(hk),2*length(hk)); 
M(:,2:2:end)=repmat(hk,1,length(hk)); 
M(:,1:2:end)=repmat(hk,1,length(hk)).'; 
Mtrans=M.';
P=zeros(2,length(hk)^2); 
P(1,:)=Mtrans(1:2:end);
P(2,:)=Mtrans(2:2:end); 

l_field=zeros(size(P,2),lmax);

for r = 1:size(lvec,1)
    lval=lvec(r);
    l_field(:,r)=lval;
end 
 
hkl_field=zeros(length(P),3,lmax+1);

for l=1:size(lvec,1)
    hkl_field(1:length(P),1,l)=P(1,:).';
    hkl_field(1:length(P),2,l)=P(2,:).';
    hkl_field(1:length(P),3,l)=l_field(:,l);
end

hklcell = num2cell(hkl_field,[1 2]); 
hklcell = reshape(hklcell,size(hkl_field,3),1); 

HKL = cell2mat(hklcell);
qxyz=zeros(size(HKL,1),5);

alpha_stern=acosd((cosd(beta)*cosd(gamma)-cosd(alpha))/...
    (sind(beta)*sind(gamma))); 

beta_stern=acosd((cosd(alpha)*cosd(gamma)-cosd(beta))/...
    (sind(alpha)*sind(gamma))); 

gamma_stern=acosd((cosd(alpha)*cosd(beta)-cosd(gamma))/...
    (sind(alpha)*sind(beta))); 

V=a.*b.*c*(1-cosd(alpha).*cosd(alpha)-cosd(beta).*cosd(beta)-cosd(gamma)...
.*cosd(gamma)+2.*cosd(alpha).*cosd(beta)*cosd(gamma))^(1/2);

a_stern=(2*pi*b*c*sind(alpha))/V; 
b_stern=(2*pi*a*c*sind(beta))/V; 
c_stern=(2*pi*a*b*sind(gamma))/V; 

gspec=(u^2*a_stern^2+v^2*b_stern^2+w^2*c_stern^2+2*u*v*a_stern*b_stern*...
    cosd(gamma_stern)+2*u*w*a_stern*c_stern*cosd(beta_stern)+2*v*w*...
    b_stern*c_stern*cosd(alpha_stern))^(1/2);

h=HKL(:,1);
k=HKL(:,2);
l=HKL(:,3);

R=(k.*w-l.*v).^2.*a.^2+(h.*w-l.*u).^2.*b.^2+...
    (h.*v-k.*u).^2.*c.^2+...
    2.*(k.*u-h.*v).*(h.*w-l.*u).*b.*c.*cosd(alpha)+...
    2.*(h.*v-k.*u).*(k.*w-l.*v).*a.*c.*cosd(beta)+...
    2.*(h.*w-l.*u).*(l.*v-k.*w).*a.*b.*cosd(gamma);

qxyz(:,1)=real(sqrt(((2.*pi).^4.*R)./(gspec.^2.*V.^2)));

qxyz(:,2)=(h.*u.*a_stern.^2+k.*v.*b_stern.^2+l.*w.*c_stern.^2+...
    (h.*v+k.*u).*a_stern.*b_stern.*cosd(gamma_stern)+...
    (h.*w+l.*u).*a_stern.*c_stern.*cosd(beta_stern)+...
    (k.*w+l.*v).*b_stern.*c_stern.*cosd(alpha_stern))./gspec;

qxyz(1:length(HKL),3)=HKL(:,1); 
qxyz(1:length(HKL),4)=HKL(:,2); 
qxyz(1:length(HKL),5)=HKL(:,3); 
end 








    
