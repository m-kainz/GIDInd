function [parameters_from_this_abg,indices_from_this_abg] = ...
    function_BUERGER_CELL_OPTIMIZATION_eff(par,QXY,QZ,QSPEC,indices,dqspec)

lqz=length(QZ);
QXYZ=sqrt(QXY.^2+QZ.^2);

hklmax=max(max(indices(:,:)));
hkl=LPermutation(-hklmax:hklmax,3);
lex=length(hkl(:,1));

QZw=repmat(QZ,lex,1)';
QXYZw=repmat(QXYZ,lex,1)';
QXYw=repmat(QXY,lex,1)';
if lqz<=12
    limit=1;
else
    limit=0.5;
end 
parameters_from_this_abg(1,1:14)=par(:,2:end);
indices_from_this_abg=indices(1:end,[3 4 5]);

indix=1;
a=par(indix,5); 
b=par(indix,6); 
gamma=par(indix,10)*pi/180;
alpha=par(indix,8)*pi/180;
beta=par(indix,9)*pi/180;
c=par(indix,7);
u=par(indix,2); 
v=par(indix,3); 
w=par(indix,4);

ZA=2*pi/a/sin(gamma);ZA2=ZA^2;
ZB=2*pi/b/sin(gamma);ZB2=ZB^2;
XG=ZA*ZB*cos(gamma);
sine=sqrt(1-cos(alpha)^2-cos(beta)^2-cos(gamma)^2+2*cos(alpha)*cos(beta)*cos(gamma))/sin(gamma);
ZC=2*pi/c/sine;
XA=(cos(alpha)*cos(gamma)-cos(beta))/sin(gamma)/sine*ZA;
XB=(cos(beta)*cos(gamma)-cos(alpha))/sin(gamma)/sine*ZB;
qspec=sqrt(u^2*ZA^2+v^2*ZB^2-2*u*v*XG+(u*XA+v*XB+w*ZC)^2);

A=[2*pi/a,0,0;-ZA*cos(gamma),ZB,0;XA,XB,ZC];

if u ~=0 || v ~=0
    n1=(u*ZA*cos(gamma)-v*ZB)/sqrt(u^2*ZA^2+v^2*ZB^2-2*u*v*XG);
    n2=u*ZA*sin(gamma)/sqrt(u^2*ZA^2+v^2*ZB^2-2*u*v*XG);
    Cosphi=(u*XA+v*XB+w*ZC)/qspec;
    Sinphi=sqrt(u^2*ZA^2+v^2*ZB^2-2*u*v*XG)/qspec;
    RR=[n1^2*(1-Cosphi)+Cosphi,n1*n2*(1-Cosphi),-n2*Sinphi;n1*n2*(1-Cosphi),n2^2*(1-Cosphi)+Cosphi,n1*Sinphi;n2*Sinphi,-n1*Sinphi,Cosphi];
else
    RR=[1,0,0;0,1,0;0,0,abs(w)/w];
end

G=RR*A;

g(:,:)=G*hkl';
gxyz(:)=sqrt(g(1,:).^2+g(2,:).^2+g(3,:).^2);
gz(:)=g(3,:);
gxy(:)=sqrt(g(1,:).^2+g(2,:).^2);

gzw=repmat(gz,lqz,1);
gxyzw=repmat(gxyz,lqz,1);
gxyw=repmat(gxy,lqz,1);


Diff=sqrt((QXYZw-gxyzw).^2/3+(QZw-gzw).^2/3+(QXYw-gxyw).^2/3);
[~,minlab]=min(Diff,[],2);

for n=1:lqz
    H(n,1)=hkl(minlab(n),1);
    H(n,2)=hkl(minlab(n),2);
    H(n,3)=hkl(minlab(n),3);
end

qqxyz=(2*pi)/sqrt(1-cos(alpha)^2-cos(beta)^2-cos(gamma)^2+...
    2*cos(alpha)*cos(beta)*cos(gamma))*sqrt(H(:,1).^2*(sin(alpha)/a)^2+...
    H(:,2).^2*(sin(beta)/b)^2+H(:,3).^2*(sin(gamma)/c)^2+...
    2*H(:,1).*H(:,2)/a/b*(cos(alpha)*cos(beta)-cos(gamma))+...
    2*H(:,1).*H(:,3)/a/c*(cos(alpha)*cos(gamma)-cos(beta))+...
    2*H(:,2).*H(:,3)/b/c*(cos(beta)*cos(gamma)-cos(alpha)));
qqz=(2*pi)/sqrt(1-cos(alpha)^2-cos(beta)^2-cos(gamma)^2+...
    2*cos(alpha)*cos(beta)*cos(gamma))*(H(:,1)*u*(sin(alpha)/a)^2+...
    H(:,2)*v*(sin(beta)/b)^2+H(:,3)*w*(sin(gamma)/c)^2+...
    (H(:,1)*v+u*H(:,2))/a/b*(cos(alpha)*cos(beta)-cos(gamma))+...
    (H(:,1)*w+u*H(:,3))/a/c*(cos(alpha)*cos(gamma)-cos(beta))+...
    (H(:,2)*w+v*H(:,3))/b/c*(cos(beta)*cos(gamma)-...
    cos(alpha)))/sqrt(u^2*(sin(alpha)/a)^2+v^2*(sin(beta)/b)^2+...
    w^2*(sin(gamma)/c)^2+2*u*v/a/b*(cos(alpha)*cos(beta)-cos(gamma))+...
    2*u*w/a/c*(cos(alpha)*cos(gamma)-cos(beta))+...
    2*v*w/b/c*(cos(beta)*cos(gamma)-cos(alpha)));
qqxy=(2*pi)*sqrt((H(:,2)*w-H(:,3)*v).^2/b^2/c^2+...
    (H(:,1)*w-H(:,3)*u).^2/a^2/c^2+(H(:,1)*v-...
    H(:,2)*u).^2/a^2/b^2+2*(H(:,2)*u-H(:,1)*v).*(H(:,1)*w-...
    H(:,3)*u)/a^2/b/c*cos(alpha)+2*(H(:,1)*v-H(:,2)*u).*(H(:,2)*w-...
    H(:,3)*v)/b^2/a/c*cos(beta)+2*(H(:,1)*w-H(:,3)*u).*(H(:,3)*v-...
    H(:,2)*w)/c^2/b/a*cos(gamma))/sqrt(u^2*(sin(alpha)/a)^2+...
    v^2*(sin(beta)/b)^2+w^2*(sin(gamma)/c)^2+...
    2*u*v/a/b*(cos(alpha)*cos(beta)-cos(gamma))+...
    2*u*w/a/c*(cos(alpha)*cos(gamma)-cos(beta))+...
    2*v*w/b/c*(cos(beta)*cos(gamma)-cos(alpha)));

qxyz=sqrt(H(:,1).^2*ZA2 + H(:,2).^2*ZB2 - 2*H(:,1).*H(:,2)*XG +...
    (H(:,1)*XA+H(:,2)*XB+H(:,3)*ZC).^2);

wu=sine*sin(gamma);wuq=sin(alpha)*sin(beta)*sin(gamma)/wu^2;
cosalpstar=(cos(beta)*cos(gamma)-cos(alpha))/sin(beta)/sin(gamma);
cosbetstar=(cos(alpha)*cos(gamma)-cos(beta))/sin(alpha)/sin(gamma);
cosgamstar=(cos(alpha)*cos(beta)-cos(gamma))/sin(alpha)/sin(beta);


fa=-(H(:,1).^2*(2*pi*sin(alpha)/wu/a)^2+H(:,1).*H(:,2)*(2*pi/a/wu)*(2*pi/b/wu)*(cos(alpha)*cos(beta)-cos(gamma))+H(:,1).*H(:,3)*(2*pi/wu/a)*(2*pi/wu/c)*(cos(alpha)*cos(gamma)-cos(beta)))/a.*qqxyz.^(-1);
fb=-(H(:,2).^2*(2*pi*sin(beta)/wu/b)^2+H(:,1).*H(:,2)*(2*pi/a/wu)*(2*pi/b/wu)*(cos(alpha)*cos(beta)-cos(gamma))+H(:,2).*H(:,3)*(2*pi/wu/b)*(2*pi/wu/c)*(cos(beta)*cos(gamma)-cos(alpha)))/b.*qqxyz.^(-1);
fc=-(H(:,3).^2*(2*pi*sin(gamma)/wu/c)^2+H(:,1).*H(:,3)*(2*pi/a/wu)*(2*pi/c/wu)*(cos(gamma)*cos(alpha)-cos(beta))+H(:,2).*H(:,3)*(2*pi/wu/b)*(2*pi/wu/c)*(cos(beta)*cos(gamma)-cos(alpha)))/c.*qqxyz.^(-1);
falp=cosalpstar*wuq*qxyz(:)+sin(alpha)*(2*pi/wu)^2*(cos(alpha)/a^2*H(:,1).^2-cos(beta)/a/b*H(:,1).*H(:,2)-cos(gamma)/a/c*H(:,1).*H(:,3)+1/(b*c)*H(:,2).*H(:,3)).*qqxyz.^(-1);
fbet=cosbetstar*wuq*qxyz(:)+sin(beta)*(2*pi/wu)^2*(H(:,2).^2*cos(beta)/b^2-H(:,1).*H(:,2)*cos(alpha)/a/b-H(:,2).*H(:,3)/b/c*cos(gamma)+H(:,1).*H(:,3)/a/c).*qqxyz.^(-1);
fgam=cosgamstar*wuq*qxyz(:)+sin(gamma)*(2*pi/wu)^2*(H(:,3).^2*cos(gamma)/c^2-H(:,1).*H(:,3)*cos(alpha)/a/c-H(:,2).*H(:,3)/b/c*cos(beta)+H(:,2).*H(:,1)/b/a).*qqxyz.^(-1);


ffa1=(u^2*(2*pi*sin(alpha)/wu/a)^2+u*v*(2*pi/a/wu)*(2*pi/b/wu)*(cos(alpha)*cos(beta)-cos(gamma))+u*w*(2*pi/wu/a)*(2*pi/wu/c)*(cos(alpha)*cos(gamma)-cos(beta)))/a/qspec^2.*qqz(:);
ffb1=(v^2*(2*pi*sin(beta)/wu/b)^2+u*v*(2*pi/a/wu)*(2*pi/b/wu)*(cos(alpha)*cos(beta)-cos(gamma))+v*w*(2*pi/wu/b)*(2*pi/wu/c)*(cos(beta)*cos(gamma)-cos(alpha)))/b/qspec^2.*qqz(:);
ffc1=(w^2*(2*pi*sin(gamma)/wu/c)^2+u*w*(2*pi/a/wu)*(2*pi/c/wu)*(cos(gamma)*cos(alpha)-cos(beta))+v*w*(2*pi/wu/b)*(2*pi/wu/c)*(cos(beta)*cos(gamma)-cos(alpha)))/c/qspec^2.*qqz(:);
ffa2=-(2*H(:,1)*u*(2*pi*sin(alpha)/wu/a)^2+(H(:,1)*v+u*H(:,2))*(2*pi/a/wu)*(2*pi/b/wu)*(cos(alpha)*cos(beta)-cos(gamma))+(H(:,1)*w+u*H(:,3))*(2*pi/wu/a)*(2*pi/wu/c)*(cos(alpha)*cos(gamma)-cos(beta)))/a/qspec;
ffb2=-(2*H(:,2)*v*(2*pi*sin(beta)/wu/b)^2+(H(:,1)*v+u*H(:,2))*(2*pi/a/wu)*(2*pi/b/wu)*(cos(alpha)*cos(beta)-cos(gamma))+(H(:,2)*w+v*H(:,3))*(2*pi/wu/b)*(2*pi/wu/c)*(cos(beta)*cos(gamma)-cos(alpha)))/b/qspec;
ffc2=-(2*H(:,3)*w*(2*pi*sin(gamma)/wu/c)^2+(H(:,1)*w+u*H(:,3))*(2*pi/a/wu)*(2*pi/c/wu)*(cos(gamma)*cos(alpha)-cos(beta))+(H(:,2)*w+v*H(:,3))*(2*pi/wu/b)*(2*pi/wu/c)*(cos(beta)*cos(gamma)-cos(alpha)))/c/qspec;
ffa=ffa1+ffa2;ffb=ffb1+ffb2;ffc=ffc1+ffc2;
ffalp=cosalpstar*wuq*qqz(:)+sin(alpha)*(2*pi/wu)^2*(2*cos(alpha)/a^2*H(:,1)*u-cos(beta)/a/b*(H(:,1)*v+u*H(:,2))-cos(gamma)/a/c*(H(:,1)*w+u*H(:,3))+1/(b*c)*(H(:,2)*w+v*H(:,3)))/qspec-sin(alpha)*(2*pi/wu/qspec)^2*(cos(alpha)/a^2*u^2-cos(beta)/a/b*u*v-cos(gamma)/a/c*u*w+1/(b*c)*v*w)*qqz(:);
ffbet=cosbetstar*wuq*qqz(:)+sin(beta)*(2*pi/wu)^2*(2*cos(beta)/b^2*H(:,2)*v-cos(alpha)/a/b*(H(:,1)*v+u*H(:,2))-cos(gamma)/b/c*(H(:,2)*w+v*H(:,3))+1/(a*c)*(H(:,1)*w+u*H(:,3)))/qspec-sin(beta)*(2*pi/wu/qspec)^2*(cos(beta)/b^2*v^2-cos(alpha)/a/b*u*v-cos(gamma)/b/c*v*w+1/(a*c)*u*w)*qqz(:);
ffgam=cosgamstar*wuq*qqz(:)+sin(gamma)*(2*pi/wu)^2*(2*cos(gamma)/c^2*H(:,3)*w-cos(alpha)/a/c*(H(:,1)*w+u*H(:,3))-cos(beta)/b/c*(H(:,2)*w+v*H(:,3))+1/(a*b)*(H(:,1)*v+u*H(:,2)))/qspec-sin(gamma)*(2*pi/wu/qspec)^2*(cos(gamma)/c^2*w^2-cos(alpha)/a/c*u*w-cos(beta)/b/c*v*w+1/(a*b)*u*v)*qqz(:);

fffa=(fa.*qqxyz-ffa.*qqz).*qqxy.^(-1);
fffb=(fb.*qqxyz-ffb.*qqz).*qqxy.^(-1);
fffc=(fc.*qqxyz-ffc.*qqz).*qqxy.^(-1);
fffalp=(falp.*qqxyz-ffalp.*qqz).*qqxy.^(-1);
fffbet=(fbet.*qqxyz-ffbet.*qqz).*qqxy.^(-1);
fffgam=(fgam.*qqxyz-ffgam.*qqz).*qqxy.^(-1);

F11(:)=fa.^2;F12(:)=fa.*fb;F13(:)=fa.*fc;F14(:)=fa.*falp;F15(:)=fa.*fbet;F16(:)=fa.*fgam;
F22(:)=fb.^2;F23(:)=fb.*fc;F24(:)=fb.*falp;F25(:)=fb.*fbet;F26(:)=fb.*fgam;
F33(:)=fc.^2;F34(:)=fc.*falp;F35(:)=fc.*fbet;F36(:)=fc.*fgam;
F44(:)=falp.^2;F45(:)=falp.*fbet;F46(:)=falp.*fgam;
F55(:)=fbet.^2;F56(:)=fbet.*fgam;
F66(:)=fgam.^2;
qq=QXYZ'-qqxyz;
F1(:)=qq.*fa;F2(:)=qq.*fb;F3(:)=qq.*fc;F4(:)=qq.*falp;F5(:)=qq.*fbet;F6(:)=qq.*fgam;

FF11(:)=ffa.^2;FF12(:)=ffa.*ffb;FF13(:)=ffa.*ffc;FF14(:)=ffa.*ffalp;FF15(:)=ffa.*ffbet;FF16(:)=ffa.*ffgam;
FF22(:)=ffb.^2;FF23(:)=ffb.*ffc;FF24(:)=ffb.*ffalp;FF25(:)=ffb.*ffbet;FF26(:)=ffb.*ffgam;
FF33(:)=ffc.^2;FF34(:)=ffc.*ffalp;FF35(:)=ffc.*ffbet;FF36(:)=ffc.*ffgam;
FF44(:)=ffalp.^2;FF45(:)=ffalp.*ffbet;FF46(:)=ffalp.*ffgam;
FF55(:)=ffbet.^2;FF56(:)=ffbet.*ffgam;
FF66(:)=ffgam.^2;
qq=QZ'-qqz;
FF1(:)=qq.*ffa;FF2(:)=qq.*ffb;FF3(:)=qq.*ffc;FF4(:)=qq.*ffalp;FF5(:)=qq.*ffbet;FF6(:)=qq.*ffgam;

FFF11(:)=fffa.^2;FFF12(:)=fffa.*fffb;FFF13(:)=fffa.*fffc;FFF14(:)=fffa.*fffalp;FFF15(:)=fffa.*fffbet;FFF16(:)=fffa.*fffgam;
FFF22(:)=fffb.^2;FFF23(:)=fffb.*fffc;FFF24(:)=fffb.*fffalp;FFF25(:)=fffb.*fffbet;FFF26(:)=fffb.*fffgam;
FFF33(:)=fffc.^2;FFF34(:)=fffc.*fffalp;FFF35(:)=fffc.*fffbet;FFF36(:)=fffc.*fffgam;
FFF44(:)=fffalp.^2;FFF45(:)=fffalp.*fffbet;FFF46(:)=fffalp.*fffgam;
FFF55(:)=fffbet.^2;FFF56(:)=fffbet.*fffgam;
FFF66(:)=fffgam.^2;
qq=QXY'-qqxy;
FFF1(:)=qq.*fffa;FFF2(:)=qq.*fffb;FFF3(:)=qq.*fffc;FFF4(:)=qq.*fffalp;FFF5(:)=qq.*fffbet;FFF6(:)=qq.*fffgam;


S11=sum(F11);
S12=sum(F12);
S13=sum(F13);
S14=sum(F14);
S15=sum(F15);
S16=sum(F16);
S22=sum(F22);
S23=sum(F23);
S24=sum(F24);
S25=sum(F25);
S26=sum(F26);
S33=sum(F33);
S34=sum(F34);
S35=sum(F35);
S36=sum(F36);
S44=sum(F44);
S45=sum(F45);
S46=sum(F46);
S55=sum(F55);
S56=sum(F56);
S66=sum(F66);
S1=sum(F1);S2=sum(F2);S3=sum(F3);S4=sum(F4);S5=sum(F5);S6=sum(F6);
N=[S1,S2,S3,S4,S5,S6]';
M=[S11,S12,S13,S14,S15,S16;S12,S22,S23,S24,S25,S26;S13,S23,S33,S34,S35,S36;S14,S24,S34,S44,S45,S46;S15,S25,S35,S45,S55,S56;S16,S26,S36,S46,S56,S66];

SS11=sum(FF11);
SS12=sum(FF12);
SS13=sum(FF13);
SS14=sum(FF14);
SS15=sum(FF15);
SS16=sum(FF16);
SS22=sum(FF22);
SS23=sum(FF23);
SS24=sum(FF24);
SS25=sum(FF25);
SS26=sum(FF26);
SS33=sum(FF33);
SS34=sum(FF34);
SS35=sum(FF35);
SS36=sum(FF36);
SS44=sum(FF44);
SS45=sum(FF45);
SS46=sum(FF46);
SS55=sum(FF55);
SS56=sum(FF56);
SS66=sum(FF66);
SS1=sum(FF1);SS2=sum(FF2);SS3=sum(FF3);SS4=sum(FF4);SS5=sum(FF5);SS6=sum(FF6);
NN=[SS1,SS2,SS3,SS4,SS5,SS6]';
MM=[SS11,SS12,SS13,SS14,SS15,SS16;SS12,SS22,SS23,SS24,SS25,SS26;SS13,SS23,SS33,SS34,SS35,SS36;SS14,SS24,SS34,SS44,SS45,SS46;SS15,SS25,SS35,SS45,SS55,SS56;SS16,SS26,SS36,SS46,SS56,SS66];

SSS11=sum(FFF11);
SSS12=sum(FFF12);
SSS13=sum(FFF13);
SSS14=sum(FFF14);
SSS15=sum(FFF15);
SSS16=sum(FFF16);
SSS22=sum(FFF22);
SSS23=sum(FFF23);
SSS24=sum(FFF24);
SSS25=sum(FFF25);
SSS26=sum(FFF26);
SSS33=sum(FFF33);
SSS34=sum(FFF34);
SSS35=sum(FFF35);
SSS36=sum(FFF36);
SSS44=sum(FFF44);
SSS45=sum(FFF45);
SSS46=sum(FFF46);
SSS55=sum(FFF55);
SSS56=sum(FFF56);
SSS66=sum(FFF66);
SSS1=sum(FFF1);SSS2=sum(FFF2);SSS3=sum(FFF3);SSS4=sum(FFF4);SSS5=sum(FFF5);SSS6=sum(FFF6);
NNN=[SSS1,SSS2,SSS3,SSS4,SSS5,SSS6]';
MMM=[SSS11,SSS12,SSS13,SSS14,SSS15,SSS16;SSS12,SSS22,SSS23,SSS24,SSS25,SSS26;SSS13,SSS23,SSS33,SSS34,SSS35,SSS36;SSS14,SSS24,SSS34,SSS44,SSS45,SSS46;SSS15,SSS25,SSS35,SSS45,SSS55,SSS56;SSS16,SSS26,SSS36,SSS46,SSS56,SSS66];

Mges=M+MM+MMM;
Nges=N+NN+NNN;

z=1;ind1=0;
for i=1:6
    if Mges(z,:)==0
        Mges(z,:)=[];Mges(:,z)=[];Nges(z)=[];
    else
        z=z+1;ind1(i)=1; 
    end
end

param(1)=a;
param(2)=b;
param(3)=c;
param(4)=alpha;
param(5)=beta;
param(6)=gamma;


if abs(det(transpose(Mges)*Mges)) > 0.0001
    eps=Mges\Nges;
else
    eps=[0,0,0,0,0,0];
end

z=1;
for i=1:6
    if ind1(i)==1
        paramn(i)=param(i)+eps(z);
        z=z+1;
    else
        paramn(i)=param(i);
    end
end

a=paramn(1);
b=paramn(2);
c=paramn(3);
alpha=paramn(4);
beta=paramn(5);
gamma=paramn(6);


ZA=2*pi/a/sin(gamma);ZA2=ZA^2;
ZB=2*pi/b/sin(gamma);ZB2=ZB^2;
XG=ZA*ZB*cos(gamma);
sine=sqrt(1-cos(alpha)^2-cos(beta)^2-cos(gamma)^2+2*cos(alpha)*cos(beta)*cos(gamma))/sin(gamma);
ZC=2*pi/c/sine;
XA=(cos(alpha)*cos(gamma)-cos(beta))/sin(gamma)/sine*ZA;
XB=(cos(beta)*cos(gamma)-cos(alpha))/sin(gamma)/sine*ZB;
qspec=sqrt(u^2*ZA2+v^2*ZB2-2*u*v*XG+(u*XA+v*XB+w*ZC)^2);

A=[2*pi/a,0,0;-ZA*cos(gamma),ZB,0;XA,XB,ZC];

if u ~=0 || v ~=0
    n1=(u*ZA*cos(gamma)-v*ZB)/sqrt(u^2*ZA^2+v^2*ZB^2-2*u*v*XG);
    n2=u*ZA*sin(gamma)/sqrt(u^2*ZA^2+v^2*ZB^2-2*u*v*XG);
    Cosphi=(u*XA+v*XB+w*ZC)/qspec;
    Sinphi=sqrt(u^2*ZA^2+v^2*ZB^2-2*u*v*XG)/qspec;
    RR=[n1^2*(1-Cosphi)+Cosphi,n1*n2*(1-Cosphi),-n2*Sinphi;n1*n2*(1-Cosphi),n2^2*(1-Cosphi)+Cosphi,n1*Sinphi;n2*Sinphi,-n1*Sinphi,Cosphi];
else
    RR=[1,0,0;0,1,0;0,0,abs(w)/w];
end

G=RR*A;

g(:,:)=G*hkl';
gxyz(:)=sqrt(g(1,:).^2+g(2,:).^2+g(3,:).^2);
gz(:)=g(3,:);
gxy(:)=sqrt(gxyz(:).^2-gz(:).^2);
gzw=repmat(gz,lqz,1);
gxyzw=repmat(gxyz,lqz,1);
gxyw=repmat(gxy,lqz,1);

Diff=sqrt((QXYZw-gxyzw).^2/3+(QZw-gzw).^2/3+(QXYw-gxyw).^2/3);
[~,minlab]=min(Diff,[],2);

for n=1:lqz
    H(n,1)=hkl(minlab(n),1);
    H(n,2)=hkl(minlab(n),2);
    H(n,3)=hkl(minlab(n),3);
end


leng=lqz*limit;

varlau=nchoosek(1:leng,3);
levar=length(varlau(:,1));
vl=1:levar;

dt(1:levar)=0;
for i=1:levar
    dt(i)=abs(det([H(varlau(i,1),:);H(varlau(i,2),:);H(varlau(i,3),:)]));
    mle(i)=norm(H(varlau(i,1),:))+norm(H(varlau(i,2),:))+norm(H(varlau(i,3),:));
end

VL(:,1)=dt(:);
VL(:,2)=mle(:);
VL(:,3)=vl(:);
VL=sortrows(VL);
VL1=VL(:,1);VL1=VL1(VL1>0.1);leva=length(VL1);
minla=levar-leva+1;

if minla>size(VL,1)
    return
end

labmin=VL(minla,3);
H1=H(varlau(labmin,1),:)';
H2=H(varlau(labmin,2),:)';
H3=H(varlau(labmin,3),:)';
Q1=G*H1;
Q2=G*H2;
Q3=G*H3;
D=[Q1';Q2';Q3'];
n1=[H1';H2';H3'];

for i=1:lex
    VV=D\hkl(i,:)';
    V(i,:)=[norm(VV)*2*pi,VV(1),VV(2),VV(3),hkl(i,1),hkl(i,2),hkl(i,3),VV(3)*qspec];
end

W=sortrows(V);
anz=length(W(:,1));
if W(1,1)==0
    W(1:anz-1,:)=W(2:anz,:);anz=anz-1;
end
W1=W(:,1);
W2=W1(W1<=max([a,b,c]));
limi=length(W2)+2;

WW=W(1:limi,:);

seq=nchoosek(1:limi,3);
prod=cross(WW(seq(:,1),2:4),WW(seq(:,2),2:4));
vo(:,1)=abs(prod(:,1).*WW(seq(:,3),2)+prod(:,2).*WW(seq(:,3),3)+prod(:,3).*WW(seq(:,3),4))*(2*pi)^3;
vo(:,2)=1:length(seq(:,1));
vo=vo(vo(:,1)>0.01,:);
y=vo(1,2);
x=vo(:,2);
flag=0;
for xy=1:length(x)

    if flag==0
        y=x(xy);

        n2=[WW(seq(y,1),5:7);WW(seq(y,2),5:7);WW(seq(y,3),5:7)]';

        matrix=(n1\n2)';
        Hv=matrix*H(:,:)';
        Hn=Hv';

        if norm(matrix*[u;v;w]-round(matrix*[u;v;w])) < 0.001
            if norm(Hn-round(Hn)) < 0.001

                H=Hn;

                AAe=[WW(seq(y,1),2:4);WW(seq(y,2),2:4);WW(seq(y,3),2:4)]';

                cosal=dot(AAe(:,2),AAe(:,3))/norm(AAe(:,2))/norm(AAe(:,3));
                cosbe=dot(AAe(:,1),AAe(:,3))/norm(AAe(:,1))/norm(AAe(:,3));
                cosga=dot(AAe(:,1),AAe(:,2))/norm(AAe(:,1))/norm(AAe(:,2));
                if abs(abs(cosga)+abs(cosbe)+abs(cosal)-abs(cosga-cosbe-cosal))<0.0001
                    AAe(:,3)=-AAe(:,3);cosbe=-cosbe;cosal=-cosal;H(:,3)=-H(:,3);
                end
                if abs(abs(cosga)+abs(cosbe)+abs(cosal)-abs(-cosga-cosbe+cosal))<0.0001
                    AAe(:,3)=-AAe(:,3);AAe(:,2)=-AAe(:,2);cosbe=-cosbe;cosga=-cosga;H(:,3)=-H(:,3);H(:,2)=-H(:,2);
                end
                if abs(abs(cosga)+abs(cosbe)+abs(cosal)-abs(-cosga+cosbe-cosal))<0.0001
                    AAe(:,2)=-AAe(:,2);cosga=-cosga;cosal=-cosal;H(:,2)=-H(:,2);
                end


                gamma=acos(cosga);beta=acos(cosbe);alpha=acos(cosal);
                a=2*pi*norm(AAe(:,1));
                b=2*pi*norm(AAe(:,2));
                c=2*pi*norm(AAe(:,3));

                u=round(AAe(3,1)*QSPEC);v=round(AAe(3,2)*QSPEC);w=round(AAe(3,3)*QSPEC);
                u=round(u,0);
                v=round(v,0);
                w=round(w,0);
                ZA=2*pi/a/sin(gamma);ZA2=ZA^2;
                ZB=2*pi/b/sin(gamma);ZB2=ZB^2;
                XG=ZA*ZB*cos(gamma);
                sine=sqrt(1-cos(alpha)^2-cos(beta)^2-cos(gamma)^2+2*cos(alpha)*cos(beta)*cos(gamma))/sin(gamma);
                ZC=2*pi/c/sine;
                XA=(cos(alpha)*cos(gamma)-cos(beta))/sin(gamma)/sine*ZA;
                XB=(cos(beta)*cos(gamma)-cos(alpha))/sin(gamma)/sine*ZB;
                qspec=sqrt(u^2*ZA^2+v^2*ZB^2-2*u*v*XG+(u*XA+v*XB+w*ZC)^2);
                Vol = a*b*sin(gamma)*2*pi/ZC;

                qxyz=sqrt(H(:,1).^2*ZA2 + H(:,2).^2*ZB2 - 2*H(:,1).*H(:,2)*XG + (H(:,1)*XA+H(:,2)*XB+H(:,3)*ZC).^2);
                qz = (H(:,1)*u*ZA^2 + H(:,2)*v*ZB^2 -(H(:,1)*v+H(:,2)*u)*XG + (H(:,1)*XA+H(:,2)*XB+H(:,3)*ZC)*(u*XA+v*XB+w*ZC))/qspec;
                qxy=sqrt(qxyz.^2-qz.^2);
                fehlerxyz(:)=(qxyz(:)-QXYZ(:)).^2;
                fehlerxy(:)=(qxy(:)-QXY(:)).^2;
                fehlerz(:)=(qz(:)-QZ(:)).^2;
                sumerrorqxy=sum(fehlerxy(:));
                sumerrorqz=sum(fehlerz(:));
                sumerrorqxyz=sum(fehlerxyz(:));

                parameters_from_this_abg(indix,1)=u;
                parameters_from_this_abg(indix,2)=v;
                parameters_from_this_abg(indix,3)=w;

                parameters_from_this_abg(indix,4)=a;
                parameters_from_this_abg(indix,5)=b;
                parameters_from_this_abg(indix,6)=c;

                parameters_from_this_abg(indix,7)=alpha*180/pi;
                parameters_from_this_abg(indix,8)=beta*180/pi;
                parameters_from_this_abg(indix,9)=gamma*180/pi;

                parameters_from_this_abg(indix,10)=Vol;

                parameters_from_this_abg(indix,11)=sqrt(sumerrorqxyz/lqz);
                parameters_from_this_abg(indix,12)=sqrt(sumerrorqxy/lqz);
                parameters_from_this_abg(indix,13)=sqrt(sumerrorqz/lqz);  
                parameters_from_this_abg(indix,14)=abs(qspec-QSPEC);


                indices_from_this_abg(2:end,1:end,indix)=H;
                indices_from_this_abg(1,1,indix)=u;
                indices_from_this_abg(1,2,indix)=v;
                indices_from_this_abg(1,3,indix)=w;


                flag=1;
            end
        end
    end
end

if parameters_from_this_abg(1,14)>dqspec
    parameters_from_this_abg(1,11)=10;
end 
end

