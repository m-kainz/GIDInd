Part of readmefile

>>>> Executable files are named by the following order: GIDInd_year_month_day.exe -> Please make sure 
>>>> you download the latest version to avoiud unwanted bugs.
>>>>
>>>> User-defined functions are named by the following order: function_FunctionName.m
>>>>
>>>> Script version is stored as GIDIndScriptVersion_2021_02_04.m, PLEASE USE .exe file!
>>>>
>>>> .m-files necessary to run MATLAB GIDIndScriptVersion_2021_02_04.m are listed below.
>>>> file dictionary//GIDIndScriptVersion_2021_02_04.m

LPermutation.m
function_INITIALIZE_GUI.m
function_PART_ONE_INDEXING_QXY.m
function_PERMVEC_NEW.m
function_ABG_RESTRICTED.m
function_XYZ.m
function_NEWMATRIXFILLER.m
function_CALC_ABGfromXYZ_RESTRICTED_v7.m
function_SUB2_CONDITION.m
function_ABGNIGGLI.m
function_NEWINDEXING_26.m
function_NEWABGSUBS.m
function_MINKLAUEEVALUATOR.m
function_NEWRMSD_GXY.m
function_PART_TWO_INDEXING_QXY_QZ_SORT.m
function_CALCSUBSIS.m
function_NEWPACKING.m
function_NEWCELLPARAMETER_RESTRICTED.m
function_BUERGER_CELL_OPTIMIZATION_SORT.m

>>>> file dictionary//GIDInd_2021_01_06.m
function_NIGGLI_ADD_CRYSTAL.m
function_DEFAULTCRYSTAL_GUI.m
function_BUERGER_CELL.m
LPermutation.m
function_INITIALIZE_GUI.m
function_PART_ONE_INDEXING_QXY.m
function_PERMVEC_NEW.m
function_ABG_RESTRICTED.m
function_XYZ.m
function_NEWMATRIXFILLER.m
function_CALC_ABGfromXYZ_RESTRICTED_v7.m
function_SUB2_CONDITION.m
function_ABGNIGGLI.m
function_NEWINDEXING_26.m
function_NEWABGSUBS.m
function_MINKLAUEEVALUATOR.m
function_NEWRMSD_GXY.m
function_PART_TWO_INDEXING_QXY_QZ.m
function_CALCSUBSIS.m
function_NEWPACKING.m
function_NEWCELLPARAMETER_RESTRICTED.m
function_BUERGER_CELL_OPTIMIZATION_eff.m
