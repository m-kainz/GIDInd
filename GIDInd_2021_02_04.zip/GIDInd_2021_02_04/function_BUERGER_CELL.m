function [a_out,b_out,c_out,alpha_out,beta_out,gamma_out,u_out,...
    v_out,w_out,Vol_out] = function_BUERGER_CELL(a,b,c,...
    alpha_deg,beta_deg,gamma_deg,u,v,w,QXY,QZ,QSPEC,hklmax)



lqz=length(QZ);
QXYZ=sqrt(QXY.^2+QZ.^2);
limit=0.5;

alpha=alpha_deg*pi/180;
beta=beta_deg*pi/180;
gamma=gamma_deg*pi/180;

ZA=2*pi/a/sin(gamma);
ZA2=ZA^2;
ZB=2*pi/b/sin(gamma);
ZB2=ZB^2;
XG=ZA*ZB*cos(gamma);
sine=sqrt(1-cos(alpha)^2-cos(beta)^2-cos(gamma)^2+...
    2*cos(alpha)*cos(beta)*cos(gamma))/sin(gamma);
ZC=2*pi/c/sine;
XA=(cos(alpha)*cos(gamma)-cos(beta))/sin(gamma)/sine*ZA;
XB=(cos(beta)*cos(gamma)-cos(alpha))/sin(gamma)/sine*ZB;
qspec=sqrt(u^2*ZA2+v^2*ZB2-2*u*v*XG+(u*XA+v*XB+w*ZC)^2);


laueindh=hklmax;
laueindk=hklmax;
laueindl=hklmax;
HKLh=-laueindh:laueindh;
HKLk=-laueindk:laueindk;
HKLl=-laueindl:laueindl;
leh=length(HKLh);
lek=length(HKLk);
lel=length(HKLl);

clear x, clear hkl
x=repmat(HKLh,lek*lel,1);hkl(:,1)=x(:)';
x=repmat(HKLk,lel,leh);hkl(:,2)=x(:)';
x=repmat(HKLl,1,leh*lek);hkl(:,3)=x(:)';
lex=length(hkl(:,1));

clear QZw, clear QXYw; clear QXYw
QZw=repmat(QZ,lex,1)';
QXYZw=repmat(QXYZ,lex,1)';
QXYw=repmat(QXY,lex,1)';

A=[2*pi/a,0,0;-ZA*cos(gamma),ZB,0;XA,XB,ZC];

if u ~=0 || v ~=0
    n1=(u*ZA*cos(gamma)-v*ZB)/sqrt(u^2*ZA^2+v^2*ZB^2-2*u*v*XG);
    n2=u*ZA*sin(gamma)/sqrt(u^2*ZA^2+v^2*ZB^2-2*u*v*XG);
    Cosphi=(u*XA+v*XB+w*ZC)/qspec;
    Sinphi=sqrt(u^2*ZA^2+v^2*ZB^2-2*u*v*XG)/qspec;
    RR=[n1^2*(1-Cosphi)+Cosphi,n1*n2*(1-Cosphi),...
        -n2*Sinphi;n1*n2*(1-Cosphi),n2^2*(1-Cosphi)+...
        Cosphi,n1*Sinphi;n2*Sinphi,-n1*Sinphi,Cosphi];
else
    RR=[1,0,0;0,1,0;0,0,abs(w)/w];
end

G=RR*A;

clear g, clear gxyz, clear gz, clear gxy
g(:,:)=G*hkl';
gxyz(:)=sqrt(g(1,:).^2+g(2,:).^2+g(3,:).^2);
gz(:)=g(3,:);
gxy(:)=sqrt(gxyz(:).^2-gz(:).^2);
clear gzw, clear gxyw, clear gxyzw
gzw=repmat(gz,lqz,1);
gxyzw=repmat(gxyz,lqz,1);
gxyw=repmat(gxy,lqz,1);

clear Diff
Diff=sqrt((QXYZw-gxyzw).^2/3+(QZw-gzw).^2/3+(QXYw-gxyw).^2/3);
[~,minlab]=min(Diff,[],2);

clear H
for n=1:lqz
    H(n,1)=hkl(minlab(n),1);
    H(n,2)=hkl(minlab(n),2);
    H(n,3)=hkl(minlab(n),3);
end


leng=lqz*limit;

varlau=nchoosek(1:leng,3);
levar=length(varlau(:,1));
vl=1:levar;
clear dt, clear mle
dt(1:levar)=0;
for i=1:levar
    dt(i)=abs(det([H(varlau(i,1),:);H(varlau(i,2),:);H(varlau(i,3),:)]));
    mle(i)=norm(H(varlau(i,1),:))+norm(H(varlau(i,2),:))+norm(H(varlau(i,3),:));
end
clear VL, clear VL1
VL(:,1)=dt(:);
VL(:,2)=mle(:);
VL(:,3)=vl(:);
VL=sortrows(VL);
VL1=VL(:,1);VL1=VL1(VL1>0.1);leva=length(VL1);minla=levar-leva+1;
dtmin=VL(minla,1);
labmin=VL(minla,3);

clear H1, clear H2, clear H3
H1=H(varlau(labmin,1),:)';
H2=H(varlau(labmin,2),:)';
H3=H(varlau(labmin,3),:)';

Q1=G*H1;
Q2=G*H2;
Q3=G*H3;

D=[Q1';Q2';Q3'];

n1=[H1';H2';H3'];

clear VV, clear V
for i=1:lex
    VV=D\hkl(i,:)';
    V(i,:)=[norm(VV)*2*pi,VV(1),VV(2),VV(3),hkl(i,1),hkl(i,2),hkl(i,3),VV(3)*qspec];
end
clear W, clear WW, clear W1, clear W2
W=sortrows(V);
anz=length(W(:,1));
if W(1,1)==0
    W(1:anz-1,:)=W(2:anz,:);anz=anz-1;
end
W1=W(:,1);
W2=W1(W1<=max([a,b,c]));
limi=length(W2)+2;

WW=W(1:limi,:);

clear vo
seq=nchoosek(1:limi,3);
prod=cross(WW(seq(:,1),2:4),WW(seq(:,2),2:4));
vo(:,1)=abs(prod(:,1).*WW(seq(:,3),2)+prod(:,2).*WW(seq(:,3),3)+prod(:,3).*WW(seq(:,3),4))*(2*pi)^3;

vo(:,2)=1:length(seq(:,1));
vo=vo(vo(:,1)>0.01,:);

y=vo(1,2);
x=vo(:,2);

flag=0;

for xy=1:length(x)

    if flag==0
        y=x(xy);

        n2=[WW(seq(y,1),5:7);WW(seq(y,2),5:7);WW(seq(y,3),5:7)]';

        matrix=(n1\n2)';
        Hv=matrix*H(:,:)';
        Hn=Hv';

        if norm(matrix*[u;v;w]-round(matrix*[u;v;w])) < 0.001
            if norm(Hn-round(Hn)) < 0.001

                H=Hn;

                AAe=[WW(seq(y,1),2:4);WW(seq(y,2),2:4);WW(seq(y,3),2:4)]';

                cosal=dot(AAe(:,2),AAe(:,3))/norm(AAe(:,2))/norm(AAe(:,3));
                cosbe=dot(AAe(:,1),AAe(:,3))/norm(AAe(:,1))/norm(AAe(:,3));
                cosga=dot(AAe(:,1),AAe(:,2))/norm(AAe(:,1))/norm(AAe(:,2));
                if abs(abs(cosga)+abs(cosbe)+abs(cosal)-abs(cosga-cosbe-cosal))<0.0001
                    AAe(:,3)=-AAe(:,3);cosbe=-cosbe;cosal=-cosal;H(:,3)=-H(:,3);
                end
                if abs(abs(cosga)+abs(cosbe)+abs(cosal)-abs(-cosga-cosbe+cosal))<0.0001
                    AAe(:,3)=-AAe(:,3);AAe(:,2)=-AAe(:,2);cosbe=-cosbe;cosga=-cosga;H(:,3)=-H(:,3);H(:,2)=-H(:,2);
                end
                if abs(abs(cosga)+abs(cosbe)+abs(cosal)-abs(-cosga+cosbe-cosal))<0.0001
                    AAe(:,2)=-AAe(:,2);cosga=-cosga;cosal=-cosal;H(:,2)=-H(:,2);
                end


                gamma=acos(cosga);
                gamma_out=gamma*180/pi;
                beta=acos(cosbe);
                beta_out=beta*180/pi;
                alpha=acos(cosal);
                alpha_out=alpha*180/pi;
                a=2*pi*norm(AAe(:,1));
                a_out=a;
                b=2*pi*norm(AAe(:,2));
                b_out=b;
                c=2*pi*norm(AAe(:,3));
                c_out=c;
                tolerance_zero = 1.e-6;
                u=round(AAe(3,1)*QSPEC);
                u(u<0 & u>-tolerance_zero) = 0;
                v=round(AAe(3,2)*QSPEC);
                v(v<0 & v>-tolerance_zero) = 0;
                w=round(AAe(3,3)*QSPEC);
                w(w<0 & w>-tolerance_zero) = 0;
                u_out=u;
                v_out=v;
                w_out=w;
                
                sine=sqrt(1-cos(alpha)^2-cos(beta)^2-cos(gamma)^2+2*cos(alpha)*cos(beta)*cos(gamma))/sin(gamma);
                ZC=2*pi/c/sine;

                Vol = a*b*sin(gamma)*2*pi/ZC;
                Vol_out=Vol;

                flag=1;
            end
        end
    end
end

end

