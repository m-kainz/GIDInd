function [names,indexed] = ...
function_PART_ONE_INDEXING_QXY(stop_trigger,restriction_trigger,redundanzhk,limit_fuer_hk_1,...
limit_fuer_hk_2,UV_permutations,qspecs,datapoints,qxym,dqxy_cutoff,...
a_lower_limit,a_upper_limit,b_lower_limit,b_upper_limit,...
gamma_lower_limit,gamma_upper_limit)

f = uifigure;
d = uiprogressdlg(f,'Title','Status bar: Derivation of [a,b,gamma]',...
    'Message','Opening the application');

HK_permutations_6er=LPermutation(-limit_fuer_hk_1:limit_fuer_hk_1,6);
[HK] = function_PERMVEC_NEW(limit_fuer_hk_2);

ABG_out=zeros(size(HK_permutations_6er,1),6,...
size(UV_permutations,1),'single');

size_of_ABG_12=size(ABG_out);
d.Value=.1;
d.Message = 'Initialize data points.';
pause(2)

d.Value=.30;
d.Message='Create and solve possible matrices for [a,b,gamma]. Request parallel pool.';

if stop_trigger==true
    names=[];indexed=[];
    close(d)
    close(f)
    return
end
d.Value=.50;
d.Message='Calculate possible sets of [a,b,gamma]. Depending on your setting, this part could take longer. ';
parfor uv_index=1:size(UV_permutations,1)
    
    uv=UV_permutations(uv_index,:);
    ABG_out(:,:,uv_index) = function_ABG_RESTRICTED(restriction_trigger,HK_permutations_6er,...
        qspecs,uv,qxym,size_of_ABG_12,...
        a_lower_limit,a_upper_limit,b_lower_limit,b_upper_limit,...
        gamma_lower_limit,gamma_upper_limit);
       
end

valset=1;

if valset==1
    d.Value=.80;
    d.Message='Solutions obtained. Indexing qxy data.';
    d.Message='Solutions obtained. Indexing qxy data..';
    d.Message='Solutions obtained. Indexing qxy data...';
end 

if stop_trigger==true
    names=[];indexed=[];
    close(d)
    close(f)
    return
end

names_w_zeros=reshape(permute(ABG_out,[1 3 2]),[],...
    size(ABG_out,2),1);

idefix=find(~all(names_w_zeros==0,2));
ABG_for_indexing=names_w_zeros(idefix,:);

[indexed_datapoints_red,label_of_indexed_datapoints_red] =...
    function_NEWINDEXING_26(HK,ABG_for_indexing,datapoints,redundanzhk);
if stop_trigger==true
    names=[];indexed=[];
    close(d)
    close(f)
    return
end

d.Value=.95;
d.Message = 'Indexing of qxy data finished. Calculate RMSDs.';
pause(2)

[names,indexed] = function_NEWRMSD_GXY(...
    indexed_datapoints_red,label_of_indexed_datapoints_red,...
    redundanzhk,dqxy_cutoff);

if stop_trigger==true
    names=[];indexed=[];
    close(d)
    close(f)
    return
end
d.Value=1;
d.Message = 'Finished. Please check Result Panel below';
close(d)
close(f)
end



