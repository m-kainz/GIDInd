function [INDEXED_with_subs_NEW] = ...
    function_NEWPACKING(INDEXED_with_subs,redundanzhk)

rlength=2+3*redundanzhk; 
number_of_solutions=size(INDEXED_with_subs,3);
INDEXED_with_subs_NEW=zeros(size(INDEXED_with_subs,1),...
    size(INDEXED_with_subs,2)+rlength,'single');

Messwerte_qz=INDEXED_with_subs(2:redundanzhk:end,1:2,1);
package_height=size(zeros(size(Messwerte_qz,1),rlength),1);

for ind_lsg=1:number_of_solutions
    current_page_abg=INDEXED_with_subs(:,:,ind_lsg);
    lsg_abg_ar=current_page_abg(2:end,1:5); 
    ausgabe_mw=zeros(size(Messwerte_qz,1),rlength,'single');
    ind_fuer_paket=1;
    for ind_mw=1:redundanzhk:size(lsg_abg_ar,1)-redundanzhk+1
        
        paket_redhk_er=lsg_abg_ar(ind_mw:ind_mw+redundanzhk-1,:); 
      
        macht_zeile_pro_qz_redhk_ohne_MW= zeros(1,rlength-2);

        irhk=1;
        for rhk=1:redundanzhk
            macht_zeile_pro_qz_redhk_ohne_MW(:,irhk:irhk+2)=paket_redhk_er(rhk,3:end);
            irhk=irhk+3;
        end 
        
        macht_zeile_pro_qz_mit_redhk=horzcat(paket_redhk_er(1,1:2),macht_zeile_pro_qz_redhk_ohne_MW);
        
        ausgabe_mw(ind_fuer_paket,:)=macht_zeile_pro_qz_mit_redhk;
        ind_fuer_paket=ind_fuer_paket+1;
        
        
    end 
   
    INDEXED_with_subs_NEW(1:size(INDEXED_with_subs,1),...
        1:size(INDEXED_with_subs,2),ind_lsg)=INDEXED_with_subs(:,:,ind_lsg);
    
    INDEXED_with_subs_NEW(1:package_height,...
        size(INDEXED_with_subs,2)+1:size(INDEXED_with_subs_NEW,2),ind_lsg)=ausgabe_mw;
   
end
end

