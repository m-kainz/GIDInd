function L = LPermutation(hkvalues,n)
ns = hkvalues(:);
n_numel = numel(hkvalues);
indis = (1:n_numel).'; 
zeilen = n_numel ^ n;   
index_matrix = reshape((1:zeilen * n).', zeilen, n);
    for i = 1 : n
        dreieck = ones(1, n_numel^(i - 1));
        spalten = repmat(indis(:,dreieck).', 1, n_numel ^ (n - i));
        index_matrix(:, i) = fliplr(spalten(:));
    end
L = single(ns(index_matrix));
end