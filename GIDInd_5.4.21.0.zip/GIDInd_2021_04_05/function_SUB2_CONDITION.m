function [ABG_out_checkpoint_1] = function_SUB2_CONDITION(ABG,qspec)

limit_for_zero=1e-5; 
za=(2*pi)./(ABG(:,end-2).*sind(ABG(:,end)));
zb=(2*pi)./(ABG(:,end-1).*sind(ABG(:,end)));
u=ABG(:,1);
v=ABG(:,2);
cosg=cosd(ABG(:,end));
argum=qspec.^2-u.^2.*za.^2-v.^2.*zb.^2+2.*u.*v.*za.*zb.*cosg;
condi=argum>limit_for_zero;
ABG_out_checkpoint_1=ABG(condi,:);

end

