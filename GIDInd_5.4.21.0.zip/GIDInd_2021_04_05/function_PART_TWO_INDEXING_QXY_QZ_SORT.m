function [final_parameters_output,final_indices_output] = ...
    function_PART_TWO_INDEXING_QXY_QZ_SORT(qspecc,niggli_on,datapoints,redundanzhk,...
    limit_fuer_l,wmax,best_abg_indexed,dqspec,...
    a_lower_limit, a_upper_limit,b_lower_limit,b_upper_limit,...
    c_lower_limit,c_upper_limit,...
    alpha_lower_limit,alpha_upper_limit,beta_lower_limit,beta_upper_limit,...
    gamma_lower_limit, gamma_upper_limit, volume_lower_limit,volume_upper_limit,f,...
    delta_qxyz_cut_off,delta_qxy_cut_off,delta_qz_cut_off)

% f = uifigure;
d = uiprogressdlg(f,'Title','Status bar: Derivation of [alpha, beta, c]',...
    'Message','Status pending...');
            
qxyz_datapoints=(best_abg_indexed(2:end,1,1).^2+...
    best_abg_indexed(2:end,2,1).^2).^(1/2);

lvec=-limit_fuer_l:limit_fuer_l;
ML=LPermutation(lvec,3);
warning off
%f
[INDEXED_with_subs]=function_CALCSUBSIS(best_abg_indexed); 
%f
[INDEXED_with_subs_NEW] = ...
    function_NEWPACKING(INDEXED_with_subs,redundanzhk);
clear INDEXED_with_subs

hk_aus_qz=LPermutation(1:redundanzhk,3);


selection_hohe=size(INDEXED_with_subs_NEW(2:redundanzhk:end,1,1),1);
n_l=numel(lvec);
w_vec=single(-wmax:wmax);
n_w=size(w_vec,2); 
nr_of_initial_matrices=single(redundanzhk.^3.*n_l.^3.*n_w);
initial_matrices=zeros(4,4,nr_of_initial_matrices,'single');

output_matrices_for_solve=repmat(initial_matrices,[1 1 1 ...
        size(INDEXED_with_subs_NEW,3)]);

d.Value=.2;
d.Message = 'Create and solve possible matrices for [alpha, beta, c]. ';
pause(1)
for ind_abgpage=1:size(INDEXED_with_subs_NEW,3)
    
    
    abg_page=INDEXED_with_subs_NEW(:,:,ind_abgpage);
    
    output_matrices_for_solve(1,1,:,ind_abgpage)=...
        ones(1,1,size(initial_matrices,3),'single').*abg_page(1,1);
    
    output_matrices_for_solve(1,2,:,ind_abgpage)=...
        ones(1,1,size(initial_matrices,3),'single').*abg_page(1,2);
    
    output_matrices_for_solve(1,4,:,ind_abgpage)=...
        ones(1,1,size(initial_matrices,3),'single').*abg_page(1,8);
    
    
    select_ausgabe_mw=abg_page(1:selection_hohe,11:end);
    qzi_values_unsorted=select_ausgabe_mw(:,2);
    [~,idx_qzi]=sort(qzi_values_unsorted,1);
    qzi_sorted=select_ausgabe_mw(idx_qzi,:);
    
    tol_diff_qz=0.01;
    
    tolconverted=tol_diff_qz/max(abs(qzi_sorted(:,2)));  
    [~,ia,~]=uniquetol(qzi_sorted(:,2),tolconverted);
    qz_for_KLR_matrix=qzi_sorted(ia,:);
   
    welches_qz=[1;2;3]; 
    qz123_cell_ges_loop=cell(size(welches_qz,1),redundanzhk);
    qz_sortiert_nur_indi=qz_for_KLR_matrix(1:3,3:end);
    qzi_sel=qz_for_KLR_matrix(1:3,2);
    qzi_abglwich=abg_page(1:end,2);
    qz1_index=qzi_abglwich==qzi_sel(1,:);
    lineqz1=abg_page(qz1_index,6);
    qz2_index=qzi_abglwich==qzi_sel(2,:);
    lineqz2=abg_page(qz2_index,6);
    qz3_index=qzi_abglwich==qzi_sel(3,:);
    lineqz3=abg_page(qz3_index,6);
    
    qziterme_rowvec=vertcat(lineqz1,lineqz2,lineqz3);
    placeholder_qzihki=zeros(size(qz_sortiert_nur_indi));

    takeval=1;   
    for hkrow=1:3
        st=1;
        for hkcol=1:redundanzhk
            placeholder_qzihki(hkrow,st:st+2)=qziterme_rowvec(takeval,:);
            st=st+3;
            takeval=takeval+1;
        end
    end 
    
    qzis_choice=placeholder_qzihki(:,1:3:end);

    for lnz=1:3
        lenzhk=1;
        for rhks=1:redundanzhk
            qz123_cell_ges_loop(lnz,rhks)={qz_sortiert_nur_indi(lnz,lenzhk:lenzhk+1)};
            lenzhk=lenzhk+3;
        end 
    end
    
    hk_cell_matrices=zeros(3,4,size(hk_aus_qz,1),'single');
    
    for poss_hk=1:size(hk_aus_qz,1)

        ind_hk=hk_aus_qz(poss_hk,:); 
        hk_cell_matrices(1,1:2,poss_hk)=qz123_cell_ges_loop{1,ind_hk(1)};
        hk_cell_matrices(1,4,poss_hk)=qzis_choice(1,ind_hk(1));
        hk_cell_matrices(2,1:2,poss_hk)=qz123_cell_ges_loop{2,ind_hk(2)};
        hk_cell_matrices(2,4,poss_hk)=qzis_choice(2,ind_hk(2));
        hk_cell_matrices(3,1:2,poss_hk)=qz123_cell_ges_loop{3,ind_hk(3)};
        hk_cell_matrices(3,4,poss_hk)=qzis_choice(3,ind_hk(3));

    end
    
    output_matrices_for_solve(2:end,:,:,ind_abgpage)=...
        repmat(repmat(hk_cell_matrices,[1 1 n_l.^3]),[1 1 n_w]);
end 

size_same_w=redundanzhk.^3.*n_l.^3;
w_arrow=reshape(repmat(w_vec,[size_same_w 1 1]),nr_of_initial_matrices,1);
w_arrow_kloo=repmat(w_arrow,[1 1 size(output_matrices_for_solve,4)]);
output_matrices_for_solve(1,3,:,:)=w_arrow_kloo;


ml=ML';
ml_expanded=repmat(ml,[redundanzhk^3 1]);
l_series_same_w=reshape(ml_expanded,[3 1 size_same_w]);
l_series_expanded_for_w=repmat(l_series_same_w, [1 1 n_w]);

l_series_expanded_for_w_kloo=repmat(l_series_expanded_for_w,...
    [1 1 size(output_matrices_for_solve,4)]);
output_matrices_for_solve(2:end,3,:)=l_series_expanded_for_w_kloo;

d.Value=.4;
d.Message = 'Compute overdeterminded systems. Depending on your setting, this part could take longer.';
pause(0.5)
d.Value=.5;
d.Message = 'Compute overdeterminded systems. Depending on your setting, this part could take longer.';
pause(0.5)
d.Value=.6;
d.Message = 'Compute overdeterminded systems. Depending on your setting, this part could take longer.';
pause(0.5)

klr_for_all_abg=zeros(7,size(output_matrices_for_solve,3),...
    size(output_matrices_for_solve,4),'single');


switch niggli_on 
    case false 
    for all_abg=1:size(klr_for_all_abg,3)

        klr=zeros(7,size(output_matrices_for_solve,3),'single');
        abg_aktuell=INDEXED_with_subs_NEW(1,4:6,all_abg);
        for i=1:size(output_matrices_for_solve,3)
            
            working_mat=output_matrices_for_solve(:,:,i,all_abg);
            if working_mat(1,1:3)==zeros(1,3)
                klr(1:end,i)=zeros(size(klr,1),1);
                
            else
               
                KLR2check=working_mat(:,1:3)\...
                    working_mat(:,end); 

                delta=-1./(2.*pi).*KLR2check(1).*abg_aktuell(1).*sind(abg_aktuell(3));
                mu=-1./(2.*pi).*KLR2check(2).*abg_aktuell(2).*sind(abg_aktuell(3));
                sin_eps=sind(abg_aktuell(3))./sqrt(sind(abg_aktuell(3)).^2+delta.^2+mu.^2+...
                    2.*delta.*mu.*cosd(abg_aktuell(3)));

                alpha2check=acosd((sin_eps.*mu+sin_eps.*delta.*cosd(abg_aktuell(3)))./sind(abg_aktuell(3)));
                beta2check=acosd((sin_eps.*delta+sin_eps.*mu.*cosd(abg_aktuell(3)))./sind(abg_aktuell(3)));
                c2check=(2.*pi)./(sin_eps.*KLR2check(3));
                
                test_c = c2check < c_lower_limit || c2check > c_upper_limit;

                if test_c == true 

                    continue

                else 

                    test_alpha = alpha2check(1) > alpha_upper_limit || alpha2check < alpha_lower_limit;

                    if test_alpha==true

                        continue

                    else
                        

                        test_beta = beta2check > beta_upper_limit || beta2check < beta_lower_limit;

                        if test_beta==true 

                            continue

                        else

                            volume2check = abg_aktuell(1).*...
                                abg_aktuell(2).*c2check.*...
                                (1-cosd(alpha2check).*...
                                cosd(alpha2check)-...
                                cosd(beta2check)...
                                .*cosd(beta2check)-...
                                cosd(abg_aktuell(3)).*...
                                cosd(abg_aktuell(3))...
                                +2.*cosd(alpha2check).*...
                                cosd(beta2check).*...
                                cosd(abg_aktuell(3))).^(1/2);

                            test_vol = volume2check > volume_upper_limit ...
                                || volume2check < volume_lower_limit;

                            if test_vol == true

                                continue

                            else 
                                
                                klr(1:3,i) = KLR2check;
                                klr(4:6,i) = working_mat(1,1:3)';
                                klr(7,i)=(working_mat(1,1)*klr(1,i)+...
                                    working_mat(1,2)*klr(2,i)+...
                                    working_mat(1,3)*klr(3,i))^2;
                                
                            end 
                        end 
                    end 
                end
            end 
        end
     
        klr_for_all_abg(:,:,all_abg)=klr;

    end 

    case true 
        
        for all_abg=1:size(klr_for_all_abg,3)

            klr=zeros(7,size(output_matrices_for_solve,3),'single');
            abg_aktuell=INDEXED_with_subs_NEW(1,4:6,all_abg);
            for i=1:size(output_matrices_for_solve,3)
            
                working_mat=output_matrices_for_solve(:,:,i,all_abg);
             

                if working_mat(1,1:3)==zeros(1,3)
                    klr(1:end,i)=zeros(size(klr,1),1);
                    
                else
               
                    KLR2check=working_mat(:,1:3)\...
                        working_mat(:,end); 
                    delta=-1./(2.*pi).*KLR2check(1).*abg_aktuell(1).*sind(abg_aktuell(3));
                    mu=-1./(2.*pi).*KLR2check(2).*abg_aktuell(2).*sind(abg_aktuell(3));
                    sin_eps=sind(abg_aktuell(3))./sqrt(sind(abg_aktuell(3)).^2+delta.^2+mu.^2+...
                        2.*delta.*mu.*cosd(abg_aktuell(3)));
                    
                    alpha2check=acosd((sin_eps.*mu+sin_eps.*delta.*cosd(abg_aktuell(3)))./sind(abg_aktuell(3)));
                    beta2check=acosd((sin_eps.*delta+sin_eps.*mu.*cosd(abg_aktuell(3)))./sind(abg_aktuell(3)));
                    c2check=(2.*pi)./(sin_eps.*KLR2check(3));

                    test_c = c2check < c_lower_limit || c2check > c_upper_limit;

                    if test_c == true 

                        continue

                    else
                        
                        test_alpha = alpha2check > alpha_upper_limit || alpha2check < alpha_lower_limit;

                        if test_alpha==true

                            continue

                        else
                            
                            test_beta = beta2check > beta_upper_limit || beta2check < beta_lower_limit;

                            if test_beta==true 

                                continue

                            else
                                
                                test_b_gt_c = abg_aktuell(2)^2 <= c2check^2;
                                
                                if test_b_gt_c == false 
                                    
                                    continue 
                               
                                else

                                    volume2check = abg_aktuell(1).*...
                                        abg_aktuell(2).*c2check.*...
                                        (1-cosd(alpha2check).*...
                                        cosd(alpha2check)-...
                                        cosd(beta2check)...
                                        .*cosd(beta2check)-...
                                        cosd(abg_aktuell(3)).*...
                                        cosd(abg_aktuell(3))...
                                        +2.*cosd(alpha2check).*...
                                        cosd(beta2check).*...
                                        cosd(abg_aktuell(3))).^(1/2);

                                    test_vol = volume2check > volume_upper_limit ...
                                        || volume2check < volume_lower_limit;

                                    if test_vol == true

                                        continue

                                    else 
                                        
                                        test_type_1= lt(alpha2check,91) && lt(beta2check,91) && lt(abg_aktuell(3),91);

                                        if test_type_1 == true 
                                            type1_1 = c2check*cosd(alpha2check) <= abg_aktuell(2)/2;

                                            if type1_1==false

                                                continue

                                            else
                                                type1_2 = c2check*cosd(beta2check) <= abg_aktuell(1)/2;

                                                if type1_2==false

                                                    continue

                                                else

                                                    klr(1:3,i) = KLR2check;
                                                    klr(4:6,i) = working_mat(1,1:3)';
                                                    klr(7,i)=(working_mat(1,1)*klr(1,i)+...
                                                        working_mat(1,2)*klr(2,i)+...
                                                        working_mat(1,3)*klr(3,i))^2;

                                                end 
                                            end 
                                        else 
                                            test_type_2= ...
                                                gt(alpha2check,89) && gt(beta2check,89) && gt(abg_aktuell(3),89);

                                            if test_type_2 == false 
                                                
                                                continue
                                                
                                            else
                                                type2_1 = c2check*abs(cosd(alpha2check)) <= abg_aktuell(2)/2;

                                                if type2_1 == false

                                                    continue

                                                else
                                                      type2_2 = c2check*abs(cosd(beta2check)) <= abg_aktuell(1)/2;

                                                      if type2_2==false
                                                          
                                                          continue
                                                          
                                                      else 
                                                          
                                                          type2_3=abg_aktuell(2)*c2check*...
                                                              abs(cosd(alpha2check))+...
                                                              abg_aktuell(1)*c2check*...
                                                              abs(cosd(beta2check))+...
                                                              abg_aktuell(1)*abg_aktuell(1)*...
                                                              abs(cosd(abg_aktuell(3))) <=...
                                                              (abg_aktuell(1)^2+abg_aktuell(2)^2)/2;

                                                          if type2_3 == false 
                                                              
                                                              continue
                                                              
                                                          else

                                                              klr(1:3,i) = KLR2check;
                                                              klr(4:6,i) = working_mat(1,1:3)';
                                                              klr(7,i)=(working_mat(1,1)*klr(1,i)+...
                                                                  working_mat(1,2)*klr(2,i)+...
                                                                  working_mat(1,3)*klr(3,i))^2;
                                                          end
                                                      end 
                                                end 
                                            end
                                        end
                                    end
                                end
                            end
                        end 
                    end 
                end 
            end
            klr_for_all_abg(:,:,all_abg)=klr;
        end 
end 
       

clear output_matrices_for_solve
OUTPUT_COLLECTION_parameter=zeros(round(size(klr_for_all_abg,2)/10,0),13,...
    size(klr_for_all_abg,3),'single');

OUTPUT_COLLECTION_indexed_data_NEW=zeros(size(datapoints,1),5,...
    round(size(klr_for_all_abg,2)/10,0),size(klr_for_all_abg,3),'single');

d.Value=.7;
d.Message = 'Busy with indexing and derivation of [alpha, beta, c]';
pause(0.5)
d.Message = 'Busy with indexing and derivation of [alpha, beta, c].';
pause(0.5)
d.Message = 'Busy with indexing and derivation of [alpha, beta, c]..';
pause(0.5)
d.Message = 'Busy with indexing and derivation of [alpha, beta, c]....';
pause(0.5)

for abg_i=1:size(klr_for_all_abg,3)
    
    choose_abg=INDEXED_with_subs_NEW(:,:,abg_i); 
    sub2=choose_abg(1,9); 
    sub3=choose_abg(2:end,7); 
    za_i=(2*pi)./(choose_abg(1,4).*sind(choose_abg(1,6)));
    zb_i=(2*pi)./(choose_abg(1,5).*sind(choose_abg(1,6)));
    cosg_i=cosd(choose_abg(1,6));

    qspec=choose_abg(1,3);
    eins_d_qspec=1/choose_abg(1,3);
    qzi_list=choose_abg(2:end,1:6);

    KLR_raw_us=klr_for_all_abg(:,:,abg_i)';
    KLR_raw_us(all(~KLR_raw_us,2),:)=[]; 

    KLR_raw_us(abs(KLR_raw_us(:,3))<1e-4,:)=[]; 

    gspeccalc=sqrt(choose_abg(1,10)+KLR_raw_us(:,7));
    ind_qspec=abs(gspeccalc-qspec)<=dqspec;
    KLR_raw=KLR_raw_us(ind_qspec,:);
    KLR_raw(:,8)=abs(gspeccalc(ind_qspec,:)-qspec);
    
    

    colwid=size(qzi_list,2)+size(KLR_raw,2)+2; 
    field=zeros(size(qzi_list,1),colwid,size(KLR_raw,1),'single');

    for klr_line=1:size(KLR_raw,1)
        expanded_klr=repmat(KLR_raw(klr_line,:),[size(qzi_list,1) 1]);
        field(:,1:colwid-3,klr_line)=horzcat(qzi_list,expanded_klr(:,1:7));
        field(:,17,klr_line)=expanded_klr(:,8);
        
    end 

    l_calculated=(field(:,6,:)-field(:,3,:).*field(:,7,:)-field(:,4,:).*field(:,8,:)).*...
        field(:,9,:).^-1;

    l_tolzero=1e-4;
    l_calculated(abs(l_calculated)<=l_tolzero)=0;
    l_calculated_round=round(l_calculated,0);
    field(1:end,14,:)=l_calculated_round;
    klr_hkl_term=field(:,3,:).*field(:,7,:)+field(:,4,:).*field(:,8,:)+...
        field(:,14,:).*field(:,9,:);

    gzi=(klr_hkl_term.*sub2+sub3).*eins_d_qspec;
    qz_diff=(field(:,2,:)-gzi).^2;
    field(:,15,:)=qz_diff;

    pt1=field(:,3,:).^2.*za_i.^2+field(:,4,:).^2.*zb_i.^2-2.*field(:,3,:).*...
        field(:,4,:).*za_i.*zb_i.*cosg_i;

    gxyzi=sqrt(pt1+((gzi.*qspec-sub3).^2)./(sub2.^2));
    delta_qxyz=(gxyzi-qxyz_datapoints).^2;
    field(:,16,:)=delta_qxyz; 
    nsize4=size(field,1)/redundanzhk;
    output_abg_KLR_all=zeros(nsize4,size(field,2),size(field,3),'single');
    indzaehler=1;

     for indvierer=1:redundanzhk:size(field,1)-redundanzhk+1

        qz_4er_mit_indizes=field(indvierer:indvierer+redundanzhk-1,:,:); 
        qz_4er_nur_diff_qxyz=qz_4er_mit_indizes(:,16,:); 
        [~,ind_qmin]=mink(qz_4er_nur_diff_qxyz,1); 
        d1=reshape(ind_qmin,[size(ind_qmin,3) 1]);
        for klo=1:size(ind_qmin,3)
            output_abg_KLR_all(indzaehler,:,klo)=...
                qz_4er_mit_indizes(d1(klo),:,klo);
        end 

        indzaehler=indzaehler+1;

     end

    clear INDEXED_with_subs_NEW
    
    summieren_qxy=sum(output_abg_KLR_all(:,5,:));
    summieren_qz=sum(output_abg_KLR_all(:,15,:));
    summieren_qxyz=sum(output_abg_KLR_all(:,16,:));
    N_anzahl=size(output_abg_KLR_all,1);
    RMSD_qxy=(summieren_qxy./N_anzahl).^(1/2);
    RMSD_qz=(summieren_qz./N_anzahl).^(1/2);
    RMSD_qxyz=(summieren_qxyz./N_anzahl).^(1/2);
    size(output_abg_KLR_all);
    RMSD_qspec=output_abg_KLR_all(1,end,:);

    outputformat_abg_i=zeros(1,13,size(output_abg_KLR_all,3),'single');
    outputformat_abg_i(:,1:3,:)=repmat(choose_abg(1,4:6),[1 1 size(output_abg_KLR_all,3)]);
    outputformat_abg_i(:,4:9,:)=output_abg_KLR_all(1,[7 8 9 10 11 12],:);
    outputformat_abg_i(:,10,:)=RMSD_qxy;
    outputformat_abg_i(:,11,:)=RMSD_qz;
    outputformat_abg_i(:,12,:)=RMSD_qxyz;
    outputformat_abg_i(:,13,:)=RMSD_qspec;
    output_abg_i_with_errors_par=reshape(permute(outputformat_abg_i,[3 2 1]),...
        [size(outputformat_abg_i,3),size(outputformat_abg_i,2)]);


    OUTPUT_COLLECTION_parameter(1:size(KLR_raw,1),:,abg_i)=output_abg_i_with_errors_par;
    OUTPUT_COLLECTION_indexed_data_NEW(:,:,1:size(KLR_raw,1),abg_i)=...
        output_abg_KLR_all(:,[1 2 3 4 14],:,:);
    
end 

clear klr_for_all_abg
parameter_abg_KLR=reshape(permute(OUTPUT_COLLECTION_parameter,[1 3 2]),[],...
    size(OUTPUT_COLLECTION_parameter,2),1);

clear OUTPUT_COLLECTION_parameter

indices_abg_KLR_NEW_unsorted=reshape(OUTPUT_COLLECTION_indexed_data_NEW...
    ,[size(OUTPUT_COLLECTION_indexed_data_NEW,1),...
    size(OUTPUT_COLLECTION_indexed_data_NEW,2),...
    size(OUTPUT_COLLECTION_indexed_data_NEW,3)*...
    size(OUTPUT_COLLECTION_indexed_data_NEW,4)]);

clear OUTPUT_COLLECTION_indexed_data_NEW

index_empty=all(~parameter_abg_KLR,2); 
parameter_abg_KLR(index_empty,:)=[];
indices_abg_KLR_NEW_unsorted(:,:,index_empty)=[];

[cell_parameters_output_unsorted] = ...
    function_NEWCELLPARAMETER_RESTRICTED(parameter_abg_KLR);

clear parameter_abg_KLR
[~,indsmallest_q]=sort(cell_parameters_output_unsorted(:,11));

rownumber=1:size(cell_parameters_output_unsorted,1);
cell_parameters_output_noline=cell_parameters_output_unsorted(indsmallest_q,:);

cell_parameters_output=horzcat(rownumber',cell_parameters_output_noline);
indices_abg_KLR_NEW=indices_abg_KLR_NEW_unsorted(:,:,indsmallest_q);


ind_err=cell_parameters_output(:,12)<=delta_qxyz_cut_off & ...
    cell_parameters_output(:,13)<=delta_qz_cut_off & ...
    cell_parameters_output(:,14)<=delta_qxy_cut_off;

cell_parameters_output=cell_parameters_output(ind_err,:);
indices_abg_KLR_NEW=indices_abg_KLR_NEW(:,:,ind_err);

%neu start
[n,m,~]=size(indices_abg_KLR_NEW);
a=reshape(indices_abg_KLR_NEW,n,[],1);
b=reshape(a(:),n*m,[])';
[c,same1,~]=unique(b,'rows','stable');
indices_abg_KLR_NEW=reshape(c',n,m,[]);
cell_parameters_output=cell_parameters_output(same1,:);
% neu end

clear indices_abg_KLR_NEW_unsorted
clear cell_parameters_output_noline

d.Value=.9;
d.Message = 'Indexing finished. Cell parameter derived. ';
pause(1)

d.Value=.95;
d.Message = 'Numerical parameter optimization and search for reduced cell. Depending on your setting, this part could take longer.';
pause(1)

A1_parameter_redu_and_opti=zeros(size(cell_parameters_output,1),14);
A1_indices_redu_and_opti=zeros(size(indices_abg_KLR_NEW,1),3,size(indices_abg_KLR_NEW,3));
data_QXY=datapoints(2:end,1)'; 
data_QZ=datapoints(2:end,2)';
for solution_number=1:size(cell_parameters_output,1)

    [A1_parameter_redu_and_opti(solution_number,:),A1_indices_redu_and_opti(:,:,solution_number)] = ...
        function_BUERGER_CELL_OPTIMIZATION_SORT(cell_parameters_output(solution_number,:),...
        data_QXY,data_QZ,qspecc,indices_abg_KLR_NEW,dqspec);
      
    
end

clear cell_parameters_output
clear indices_abg_KLR_NEW

ida=A1_parameter_redu_and_opti(:,11)>=10;
A1_parameter_redu_and_opti(ida,:)=[];
A1_indices_redu_and_opti(:,:,ida)=[];

%sort out due to restrictions
restr1=A1_parameter_redu_and_opti(:,4)>=a_lower_limit ...
    & A1_parameter_redu_and_opti(:,4)<=a_upper_limit... 
    & A1_parameter_redu_and_opti(:,5)>=b_lower_limit ...
    & A1_parameter_redu_and_opti(:,5)<=b_upper_limit... 
    & A1_parameter_redu_and_opti(:,6)>=c_lower_limit ...
    & A1_parameter_redu_and_opti(:,6)<=c_upper_limit... 
    & A1_parameter_redu_and_opti(:,7)>=alpha_lower_limit ...
    & A1_parameter_redu_and_opti(:,7)<=alpha_upper_limit... 
    & A1_parameter_redu_and_opti(:,8)>=beta_lower_limit ...
    & A1_parameter_redu_and_opti(:,8)<=beta_upper_limit... 
    & A1_parameter_redu_and_opti(:,9)>=gamma_lower_limit ...
    & A1_parameter_redu_and_opti(:,9)<=gamma_upper_limit... 
    & A1_parameter_redu_and_opti(:,10)>=volume_lower_limit ...
    & A1_parameter_redu_and_opti(:,10)<=volume_upper_limit;

A1_parameter_redu_and_opti=A1_parameter_redu_and_opti(restr1,:);
A1_indices_redu_and_opti=A1_indices_redu_and_opti(:,:,restr1);

%neu start
[n,m,~]=size(A1_indices_redu_and_opti);
a=reshape(A1_indices_redu_and_opti,n,[],1);
b=reshape(a(:),n*m,[])';
[c,same1,~]=unique(b,'rows','stable');
A1_indices_redu_and_opti=reshape(c',n,m,[]);
A1_parameter_redu_and_opti=A1_parameter_redu_and_opti(same1,:);
%neu end


[~,final_sort]=sort(A1_parameter_redu_and_opti(:,11));
final_parameters=A1_parameter_redu_and_opti(final_sort,:);
final_indices=A1_indices_redu_and_opti(:,:,final_sort);
clear A1_parameter_redu_and_opti
clear A1_indices_redu_and_opti
if size(final_parameters,1)>50
    final_parameters_output=final_parameters(1:50,:);
    final_indices_output=final_indices(:,:,1:50);
else 
    final_parameters_output=final_parameters;
    final_indices_output=final_indices;
end 


d.Value=1;
d.Message = 'Sweep finished.';
close(d)
end 

