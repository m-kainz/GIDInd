function [HK] = function_PERMVEC_NEW(limit_fuer_hk)

hklim=limit_fuer_hk; 
hk=(-hklim:hklim).'; 
M=zeros(length(hk),2*length(hk)); 
M(:,2:2:end)=repmat(hk,1,length(hk)); 
M(:,1:2:end)=repmat(hk,1,length(hk)).'; 
Mtrans=M.';
P=zeros(2,length(hk)^2); 
P(1,:)=Mtrans(1:2:end);  
P(2,:)=Mtrans(2:2:end); 
HK=single(P');
end



