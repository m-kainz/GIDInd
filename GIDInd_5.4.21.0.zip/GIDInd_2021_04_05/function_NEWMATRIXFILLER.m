function [FMATRICES] = function_NEWMATRIXFILLER(hk_matrix_permutions,...
    u,v,qxym,qspec)


FMpart1=zeros(3,3,size(hk_matrix_permutions,1)); 
FMpart2=zeros(size(FMpart1,1),size(FMpart1,2),...
    size(FMpart1,3),size(qxym,2)/2);
numer=1;

for indcol=1:2:size(qxym,2)
    qxy1=qxym(1,indcol); qz1=qxym(1,indcol+1);
    qxy2=qxym(2,indcol); qz2=qxym(2,indcol+1);
    qxy3=qxym(3,indcol); qz3=qxym(3,indcol+1);
    
    for nrp=1:size(hk_matrix_permutions,1)
        h1=hk_matrix_permutions(nrp,1);
        k1=hk_matrix_permutions(nrp,2);
        h2=hk_matrix_permutions(nrp,3);
        k2=hk_matrix_permutions(nrp,4);
        h3=hk_matrix_permutions(nrp,5);
        k3=hk_matrix_permutions(nrp,6);

        position1=(qxy1.^-2).*(h1-((u.*qz1)./qspec)).^2+u.^2/qspec.^2;
        position2=(qxy2.^-2).*(h2-((u.*qz2)./qspec)).^2+u.^2/qspec.^2;
        position3=(qxy3.^-2).*(h3-((u.*qz3)./qspec)).^2+u.^2/qspec.^2;

        position4=(qxy1.^-2).*(k1-((v.*qz1)./qspec)).^2+v.^2/qspec.^2;
        position5=(qxy2.^-2).*(k2-((v.*qz2)./qspec)).^2+v.^2/qspec.^2;
        position6=(qxy3.^-2).*(k3-((v.*qz3)./qspec)).^2+v.^2/qspec.^2;

        position7=-2.*((qxy1.^-2).*(h1-((u.*qz1)./qspec)).*(k1-(v.*qz1./qspec))...
            +(u.*v)./qspec.^2);

        position8=-2.*((qxy2.^-2).*(h2-((u.*qz2)./qspec)).*(k2-(v.*qz2./qspec))...
            +(u.*v)./qspec.^2);

        position9=-2.*((qxy3.^-2).*(h3-((u.*qz3)./qspec)).*(k3-(v.*qz3./qspec))...
            +(u.*v)./qspec.^2);

        FMpart1(:,:,nrp)=[position1,position4,position7;position2,position5,...
            position8;position3,position6,position9];
    end 
    
    FMpart2(:,:,:,numer)=FMpart1;
    FMATRICES=reshape(permute(FMpart2,[1 2 3 4]),...
        [3,3,size(FMpart2,3)*size(FMpart2,4)]);
    
    numer=numer+1;
end 

end

