function [names_w_rows,indexed] = function_NEWRMSD_GXY(...
    indexed_datapoints_red,label_of_indexed_datapoints_red,...
    redundanzhk,dqxy_cutoff)

Summe_dqxy_qad_der_ersten=sum(indexed_datapoints_red(2:redundanzhk:end,5,:));
Anzahl_alle_redhk_ten=size(indexed_datapoints_red(2:redundanzhk:end,5,:),1);
RMSD_qxy_in_abgamma=(Summe_dqxy_qad_der_ersten./Anzahl_alle_redhk_ten).^(1/2);

[fehlersortiert,idx] = sort(RMSD_qxy_in_abgamma(:,:,:)); 
fehlsort1=reshape(fehlersortiert,size(fehlersortiert,3),1); 
aaasorted_nach_fehler_best4 = label_of_indexed_datapoints_red(idx,:); 
best_abg_name=horzcat(aaasorted_nach_fehler_best4,fehlsort1);
best_abg_indexed=indexed_datapoints_red(:,:,idx);
best_abg_indexed(1,7,:)=fehlsort1;

clear indexed_datapoints_red
clear label_of_indexed_datapoints_red

idefix=find(best_abg_name(:,7)<dqxy_cutoff);
names_sorted=best_abg_name(idefix,:);
indexed_sorted=best_abg_indexed(:,:,idefix);

[~,idxsort]=sort(names_sorted(:,7),1);
names=names_sorted(idxsort,:);
indexed=indexed_sorted(:,:,idxsort);

lengthnames=size(names,1);
rowvec=(1:lengthnames)';
names_w_rows=horzcat(rowvec,names);

end

