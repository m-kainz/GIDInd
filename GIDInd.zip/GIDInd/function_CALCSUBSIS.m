function [INDEXED_with_subs_out]=function_CALCSUBSIS(INDEXED_try)
INDEXED_with_subs=INDEXED_try;
u=INDEXED_try(1,1,:);
v=INDEXED_try(1,2,:);
za=INDEXED_try(1,8,:);
zb=INDEXED_try(1,9,:);
cosg=cosd(INDEXED_try(1,6,:));
qspecc=INDEXED_try(1,3,:);

guv=u.^2.*za.^2+v.^2.*zb.^2-2.*u.*v.*za.*zb.*cosg;
sub1=real((qspecc.^2-guv).^(0.5)); 
sub2=(qspecc.^2-u.^2.*za.^2-v.^2.*zb.^2+2.*u.*v.*za.*zb.*cosg).^(0.5);

INDEXED_with_subs(1,8,:)=sub1; 
INDEXED_with_subs(1,9,:)=sub2; 
INDEXED_with_subs(1,10,:)=guv; 

gzi=INDEXED_with_subs(2:end,2,:);
h=INDEXED_with_subs(2:end,3,:);
k=INDEXED_with_subs(2:end,4,:);
gziqspec=gzi.*INDEXED_with_subs(1,3,:);

zaehler=gziqspec-h.*u.*za.^2-k.*v.*zb.^2+(h.*v+k.*u).*za.*zb.*cosg;
sub3=h.*u.*za.^2+k.*v.*zb.^2-(h.*v+k.*u).*za.*zb.*cosg;
gziterme=zaehler./sub2;
INDEXED_with_subs(2:end,6,:)=gziterme; 
INDEXED_with_subs(2:end,7,:)=sub3; 
INDEXED_with_subs_out=INDEXED_with_subs;
end

