function [ABG_out] = function_ABGNIGGLI(ABG_in)

epsilon=1e-1;

% NIGGLI CRITERIA
%(1) a^2 <= b^2
indexabg=ABG_in(:,end-2).^2<=(ABG_in(:,end-1)+epsilon).^2;
abg_agreaterb=ABG_in(indexabg,:);
%abg=abg_calc;
% if gamma < 90 �
ind_gamma_kl_90=abg_agreaterb(:,end)<90;
abg_gamma_kl_90=abg_agreaterb(ind_gamma_kl_90,:);
% b * cos(gamma) <= a/2
bcosgamma=abg_gamma_kl_90(:,end-1).*cosd(abg_gamma_kl_90(:,end));
ahalbe=abg_gamma_kl_90(:,end-2)./2;
index_true_kl_90=bcosgamma(:)<=ahalbe(:);
rest_nach_niggli1=abg_gamma_kl_90(index_true_kl_90,:);
% if gamma >= 90 �
ind_gamma_gr_90=abg_agreaterb(:,end)>=90;
abg_gamma_gr_90=abg_agreaterb(ind_gamma_gr_90,:);
% b * |cos(gamma)| <= a/2
bcosgamma2=abg_gamma_gr_90(:,end-1).*abs(cosd(abg_gamma_gr_90(:,end)));
ahalbe2=abg_gamma_gr_90(:,end-2)./2;
index_true_gr_902=bcosgamma2(:)<=ahalbe2(:);
rest_nach_niggli2=abg_gamma_gr_90(index_true_gr_902,:);
ABG_out=vertcat(rest_nach_niggli1,rest_nach_niggli2);

end

