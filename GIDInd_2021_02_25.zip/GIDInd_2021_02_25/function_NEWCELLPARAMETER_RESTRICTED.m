
function [output] = function_NEWCELLPARAMETER_RESTRICTED(...
    parameter_abg_KLR)

u=parameter_abg_KLR(:,7);
v=parameter_abg_KLR(:,8);
w=parameter_abg_KLR(:,9);

a_in=parameter_abg_KLR(:,1);
b_in=parameter_abg_KLR(:,2);
gamma_in=parameter_abg_KLR(:,3);

kappa=parameter_abg_KLR(:,4);
lambda=parameter_abg_KLR(:,5);
rho=parameter_abg_KLR(:,6);

RMSD_qxy_in=parameter_abg_KLR(:,10);
RMSD_qz_in=parameter_abg_KLR(:,11);
RMSD_q_in=parameter_abg_KLR(:,12);

RMSD_qspec_in=parameter_abg_KLR(:,13);

delta=-1./(2.*pi).*kappa.*a_in.*sind(gamma_in);
mu=-1./(2.*pi).*lambda.*b_in.*sind(gamma_in);

sin_eps=sind(gamma_in)./sqrt(sind(gamma_in).^2+delta.^2+mu.^2+...
    2.*delta.*mu.*cosd(gamma_in));

cos_alpha=(sin_eps.*mu+sin_eps.*delta.*cosd(gamma_in))./sind(gamma_in);
alpha_out=acosd(cos_alpha);

cos_beta=(sin_eps.*delta+sin_eps.*mu.*cosd(gamma_in))./sind(gamma_in);
beta_out=acosd(cos_beta);
gamma_out=gamma_in;

a_out=a_in;
b_out=b_in;
c_out=(2.*pi)./(sin_eps.*rho);

vol_sq=a_out.*b_out.*c_out.*(1-cosd(alpha_out).*cosd(alpha_out)-...
    cosd(beta_out).*cosd(beta_out)-cosd(gamma_out).*cosd(gamma_out)...
    +2.*cosd(alpha_out).*cosd(beta_out).*cosd(gamma_out)).^(1/2);

output=horzcat(u,v,w,a_out,b_out,c_out,alpha_out,beta_out,gamma_out,...
    vol_sq,RMSD_q_in,RMSD_qz_in,RMSD_qxy_in,RMSD_qspec_in);


end

