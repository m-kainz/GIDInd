function [abg_with_subs,zpag,zpbg] = function_NEWABGSUBS(ABG_out)
a=ABG_out(:,4);
b=ABG_out(:,5);
sing=sind(ABG_out(:,6));
cong=cosd(ABG_out(:,6));

zpag=(2*pi)./(a.*sing);
zpbg=(2*pi)./(b.*sing);
sub1=zpag.^2;
sub2=zpbg.^2;
sub3=2.*zpag.*zpbg.*cong;
sub4=sub1.*sub2.*sing.^2;
abg_with_subs=horzcat(ABG_out,sub1,sub2,sub3,sub4);
end

