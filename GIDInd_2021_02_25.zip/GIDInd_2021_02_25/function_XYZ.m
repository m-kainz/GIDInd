function [XYZ] = function_XYZ(FMATRICES)
    XYZ = zeros(size(FMATRICES,3),3,'single');
    for i=1:size(FMATRICES,3)
        det_test=det(FMATRICES(:,:,i));
        if abs(det_test)>=1e-9
            XYZ(i,:) = FMATRICES(:,:,i)\ones(3,1);
        end 
    end
end

