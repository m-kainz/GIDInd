function [qspecs,datapoints,qxym_matrix,uniqued_line_indices] = ...
    function_INITIALIZE_GUI(raw_data,lines_to_permute)


raw_data(all(~raw_data,2),:)=[];
Messwerte_choice=raw_data(:,1:2);

[~,idxmw] = sort(Messwerte_choice(:,1));
datapoints=Messwerte_choice(idxmw,:);

nzero=1;
qspecs=Messwerte_choice(sum(Messwerte_choice==0,2)...
    ==nzero,:);
 

qcalc=(Messwerte_choice(:,1).^2+Messwerte_choice(:,2).^2).^(1/2);
MWundQ=horzcat(Messwerte_choice,qcalc);

tol_diff_qxym=0.0005;
tolconverted=tol_diff_qxym/max(abs(MWundQ(:,3)));  
[~,ia,~]=uniquetol(MWundQ(:,3),tolconverted);
q_values_uniqued=MWundQ(ia,:);

[~,iq]=sort(q_values_uniqued(:,3));
q_in_asc_order=q_values_uniqued(iq,:);

permi=1:lines_to_permute;
m_vec=LPermutation(permi,3);
m_vec(all(~m_vec,2),:)=[];
m1=m_vec((m_vec(:,1)~=m_vec(:,2)),:);
m2=m1(m1(:,2)~=m1(:,3),:);
m3=m2(m2(:,1)~=m2(:,3),:);
msumsum=m3(:,1).^2+m3(:,2).^2+m3(:,3).^2;
new_arranged_m3=zeros(size(m3));

for msi=1:size(m3,1)
    currentm3=m3(msi,:);
    [~,indm]=sort(currentm3,2);
    new_arranged_m3(msi,:)=m3(msi,indm);
end 

[uniqued_line_indices,~,~]=unique(new_arranged_m3,'rows','first');

mconc=horzcat(m3,msumsum);
[~,ia,~]=unique(mconc(:,4),'stable');

mn_index_qxym=mconc(ia,1:end-1);
q_in_asc_order(any(~q_in_asc_order,2),:)=[];

m_poss_starter=q_in_asc_order(permi,1:2);

qxym_matrix=zeros(3,2*size(mn_index_qxym,1));
mn_index_qxym=uniqued_line_indices;

for m=1:size(mn_index_qxym,1)
    indexline=mn_index_qxym(m,:);
    kmu=2*m-1;
    kmo=2*m;
    qxym_matrix(:,kmu:kmo)=[m_poss_starter(indexline(3),:);...
        m_poss_starter(indexline(2),:);m_poss_starter(indexline(1),:)];
end 

end

