
warning off


redundanzhk=4; 
lindep_limit = 0.01; 
limit_fuer_hk_1=3;
limit_fuer_l=6; 
dqspec=0.01;
limit_fuer_uv=1; 
wmax=limit_fuer_uv+1;
limit_fuer_hk_2=6;
dqxy_cutoff=0.05;

delta_qxyz_cut_off=0.03;
delta_qxy_cut_off=0.03;
delta_qz_cut_off=0.03;



filename='dataset_fina04';
delta_q_cut_off=0.05;

UV_permutations=LPermutation(-limit_fuer_uv:limit_fuer_uv,2);
lines_to_permute=4; 
[raw_data]=readmatrix(filename,'OutputType','double');

[qspecs,datapoints,qxym,line_indices] = ...
    function_INITIALIZE_GUI(raw_data,lines_to_permute);

restriction_trigger=true; % if user sets restriction check box true

a_lower_limit=5;
a_upper_limit=20;

b_lower_limit=5;
b_upper_limit=20;

gamma_lower_limit=60;
gamma_upper_limit=120;

stop_trigger=false;
[names_w_rows,indexed] = ...
function_PART_ONE_INDEXING_QXY(stop_trigger,restriction_trigger,redundanzhk,limit_fuer_hk_1,...
limit_fuer_hk_2,UV_permutations,qspecs,datapoints,qxym,delta_qxy_cut_off,...
a_lower_limit,a_upper_limit,b_lower_limit,b_upper_limit,...
gamma_lower_limit,gamma_upper_limit);

%%% INDEXING PART 1 END %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

area_parallelogram=names_w_rows(:,5).*names_w_rows(:,6).*sind(names_w_rows(:,7));
[~,ind_area]=sort(area_parallelogram,1);
names_ascending_area=names_w_rows(ind_area,:);
indices_ascending_area=indexed(:,:,ind_area);
%abg_fields_to_evaluate=indexed(:,:,ind_area);


%%% SELECT SOLUTION IN ABG %%%%

c_lower_limit=5;
c_upper_limit=20;

alpha_lower_limit=60;
alpha_upper_limit=120;

beta_lower_limit=60; 
beta_upper_limit=120;

volume_lower_limit=50;
volume_upper_limit=100000;



%%% REFORMATTING OF DATA and CREATION OF MATRICES %%%%%%%%%%%%%%%%%%%%
% normal nicht in den workspace uebergeben
% function_PART_TWO_PARALLEL

niggli_on=true;
qspecc=qspecs(1,2);


%%
parameters_output=[];
indices_output=[];
max_solutions=20000;
f=uifigure;

for possible_abg=[1:10]
    
    aV7bg_fields_to_evaluate=indices_ascending_area(:,:,possible_abg);

    [cell_parameters_output,indices_abg_KLR_NEW] = ...
        function_PART_TWO_INDEXING_QXY_QZ_SORT(qspecc,niggli_on,datapoints,redundanzhk,limit_fuer_l,wmax,...
        aV7bg_fields_to_evaluate,dqspec,a_lower_limit, a_upper_limit, b_lower_limit, ...
        b_upper_limit, c_lower_limit,c_upper_limit,...
        alpha_lower_limit,alpha_upper_limit,beta_lower_limit,beta_upper_limit,...
        gamma_lower_limit, gamma_upper_limit, volume_lower_limit,volume_upper_limit,f,...
        delta_qxyz_cut_off,delta_qxy_cut_off,delta_qz_cut_off);
    
%     [cell_parameters_output,indices_abg_KLR_NEW] = ...
%         function_PART_TWO_v12_JJ(qspecc,niggli_on,datapoints,redundanzhk,limit_fuer_l,wmax,...
%         aV7bg_fields_to_evaluate,dqspec,c_lower_limit,c_upper_limit,...
%         alpha_lower_limit,alpha_upper_limit,beta_lower_limit,beta_upper_limit,...
%         volume_lower_limit,volume_upper_limit);

    
    parameters_output=[parameters_output;cell_parameters_output];
    indices_output=cat(3,indices_output,indices_abg_KLR_NEW);
    
    min_error=min(parameters_output(:,11));
    

    [~,ind_sort_sol]=sort(parameters_output(:,11));

    parameters_output=parameters_output(ind_sort_sol,:);
    indices_output=indices_output(:,:,ind_sort_sol);

    
    
    if size(parameters_output,1)>max_solutions;
        break
    end 
    
end 
