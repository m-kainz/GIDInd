function [indexed_data] = function_MINKLAUEEVALUATOR(HK,abg_set,...
    datapoints,redundanzhk)

u=abg_set(:,1);
v=abg_set(:,2);
qspec=abg_set(:,3);
sub1=abg_set(:,7);
sub2=abg_set(:,8);
sub3=abg_set(:,9);
sub4=abg_set(:,10);
h=HK(:,1);
k=HK(:,2);
indexed_data=zeros(size(datapoints,1)*redundanzhk,5);
startpoint=1;
last=0;
for qval=1:size(datapoints,1)
    qxy=datapoints(qval,1);
    qz=datapoints(qval,2);
    qxy_calculated_HK=real((sub1.*((h-u.*qz./qspec).^2+...
        (u.*qxy./qspec).^2)+ ... 
        sub2.*((k-v.*qz./qspec).^2+(v.*qxy./qspec).^2)-...
        sub3.*((h-u.*qz./qspec).*(k-v.*qz./qspec)+u.*v.*(qxy./qspec).^2)...
        -((h.*v-k.*u).^2./qspec.^2).*sub4).^(1/2));
    
    dqxy=(qxy_calculated_HK-qxy).^2;
    qxyv=ones(size(dqxy,1),1).*qxy;
    qzv=ones(size(dqxy,1),1).*qz;
    liste_fehler=horzcat(qxyv,qzv,h,k,dqxy);
    [~,idx1]=mink(liste_fehler(:,end),redundanzhk); 
    out=liste_fehler(idx1,:);
    newend=last+size(out,1);
    indexed_data(startpoint:newend,:)=out;
    startpoint=newend+1;
    last=last+size(out,1);
end 
    
end




