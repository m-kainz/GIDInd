function [indexed_w_redundancy,name_uv_qspec_abg] = function_NEWINDEXING_26...
    (HK,ABG,datapoints,redundanzhk)
indexed_w_redundancy=zeros(size(datapoints,1)*redundanzhk+1,10,size(ABG,1),'single');
name_uv_qspec_abg=zeros(size(ABG,1),6,'single');
[abg_with_subs,za,zb] = function_NEWABGSUBS(ABG);

for sabg=1:size(ABG,1)
    abg_set=abg_with_subs(sabg,:);
    
    name_uv_qspec_abg(sabg,:)=ABG(sabg,:);
    indexed_w_redundancy(2:end,1:end-5,sabg)=...
        function_MINKLAUEEVALUATOR(HK,abg_set,datapoints,redundanzhk);
    indexed_w_redundancy(1,1:end-4,sabg)=ABG(sabg,:);
    indexed_w_redundancy(1,8,sabg)=za(sabg,:);
    indexed_w_redundancy(1,9,sabg)=zb(sabg,:);
    
end
end 




