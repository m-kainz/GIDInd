function [standard_ABG_out] = function_CALC_ABGfromXYZ_RESTRICTED_v7(restriction_trigger,...
    A,B,C,u,v,qspec,size_of_ABG_12,...
    a_lower_limit,a_upper_limit,b_lower_limit,...
    b_upper_limit,gamma_lower_limit,gamma_upper_limit)
  
standard_ABG_out=zeros(size_of_ABG_12(1),size_of_ABG_12(2),'single');

LAMBDA=(A.*B-C.^2)./(qspec.^2-u.^2.*A-v.^2.*B+2.*u.*v.*C);

za=real(sqrt(A+v.^2.*LAMBDA));
zb=real(sqrt(B+u.^2.*LAMBDA));

cosg=(C+u.*v.*LAMBDA)./(za.*zb);
gamma=acosd(cosg);

a=(2.*pi)./(za.*sind(gamma));
b=(2.*pi)./(zb.*sind(gamma));

u_v_qspec_a_b_gamma=real([ones(size(A,1),1).*u,ones(size(A,1),1).*v,...
    ones(size(A,1),1).*qspec,a,b,gamma]);

u_v_qspec_a_b_gamma(any(isnan(u_v_qspec_a_b_gamma), 2), :) = []; 

u_v_qspec_a_b_gamma(u_v_qspec_a_b_gamma(:,4)<=0,:)=[]; 
u_v_qspec_a_b_gamma(u_v_qspec_a_b_gamma(:,5)<=0,:)=[]; 


u_v_qspec_a_b_gamma(all(~u_v_qspec_a_b_gamma,2),:)=[]; 
u_v_qspec_a_b_gamma(any(isinf(u_v_qspec_a_b_gamma),2),:) = [];

ind_unten=u_v_qspec_a_b_gamma(:,end)>=60; 
sotti1=u_v_qspec_a_b_gamma(ind_unten,:); 
ind_oben=sotti1(:,end)<=120; 
ABG_before_restrictions=sotti1(ind_oben,:);



switch(restriction_trigger)
    
    case true
        aind=ABG_before_restrictions(:,end-2)>=a_lower_limit & ABG_before_restrictions(:,end-2)<=a_upper_limit;
        abg_after_a=ABG_before_restrictions(aind,:);
        
        bind=abg_after_a(:,end-1)>=b_lower_limit & abg_after_a(:,end-1)<=b_upper_limit;
        abg_after_b=abg_after_a(bind,:);
        
        gammaind=abg_after_b(:,end)>=gamma_lower_limit & abg_after_b(:,end)<=gamma_upper_limit;
        ABG=abg_after_b(gammaind,:);     
        
    case false      
        ABG=ABG_before_restrictions;
end 

[ABG1,~,~]=unique(ABG,'rows','first');

[ABG_out_checkpoint_1] = function_SUB2_CONDITION(ABG1,qspec);

[ABG_out] = function_ABGNIGGLI(ABG_out_checkpoint_1);

if isempty(ABG_out)==true
    standard_ABG_out=zeros(size_of_ABG_12(1),size_of_ABG_12(2),'single');
    
else

    
    tol_diff_a=0.15;
    tol_diff_b=0.15;
    tol_diff_gamma=0.3;
    
    tolconverteda=tol_diff_a/max(abs(ABG_out(:,4)));  
    [~,~,ia3]=uniquetol(ABG_out(:,4),tolconverteda);

    tolconvertedb=tol_diff_b/max(abs(ABG_out(:,5)));  
    [~,~,ib3]=uniquetol(ABG_out(:,5),tolconvertedb);

    tolconvertedg=tol_diff_gamma/max(abs(ABG_out(:,6)));  
    [~,~,ig3]=uniquetol(ABG_out(:,6),tolconvertedg);

    inditest=horzcat(ia3,ib3,ig3);
    [~,ia]=unique(inditest,'rows','first');
    abglistuniqued=ABG_out(ia,:);


    standard_ABG_out(1:size(abglistuniqued,1),:)=abglistuniqued;
end 
end



